"""Die-cut: Zodiac (12), Mythical Creatures (8), The Egg Club (8)."""
import math
import numpy as np
from kit2 import *

def B(rows, remap=None, oc='k', cx=20, cy=20):
    return lambda cv: sprite(cv, big(rows), cx, cy, remap, oc)

# ======================= ZODIAC — starry navy creatures with gold =======================
ZR = {'n': '#2b2a6b', 'N': '#1c1b4a', 'w': '#ffffff', 'y': '#ffd23d', 'c': '#6fd0ff'}
def Z(rows):
    def f(cv):
        sprite(cv, big(rows), 20, 20, ZR, '#c99300')
        m = cv.a[..., 3] > 0
        for (x, y) in ((9, 9), (31, 11), (12, 30), (29, 29), (20, 6)):
            if 0 <= x < S and 0 <= y < S and m[y, x] and tuple(cv.a[y, x][:3]) == (0x2b, 0x2a, 0x6b):
                cv.px(x, y, '#ffffff')
    return f

zo_aries = Z(["..yy.....yy..",
              ".y..y...y..y.",
              ".y.yy...yy.y.",
              "..yynnnnnyy..",
              "...nnnnnnn...",
              "...nwnnnwn...",
              "...nnnnnnn...",
              "....nnnnn....",
              "....nynyn....",
              ".....nnn....."])
zo_taurus = Z(["y...........y",
               "yy.........yy",
               ".yy.nnnnn.yy.",
               "..ynnnnnnny..",
               "nnnnnnnnnnnnn",
               "...nwnnnwn...",
               "...nnnnnnn...",
               "...nnnnnnn...",
               "...nNNNNNn...",
               "...nNyNyNn...",
               "....nnnnn...."])
zo_gemini = Z(["..nn....nn..",
               ".nwwn..nwwn.",
               ".nnnn..nnnn.",
               "..nn....nn..",
               ".nnnnyynnnn.",
               "n.nn....nn.n",
               "..nn....nn..",
               "..nn....nn..",
               ".n..n..n..n."])
zo_cancer = Z(["yy.......yy",
               "y.y.....y.y",
               ".yy.....yy.",
               "..n.w.w.n..",
               "..nnnnnnn..",
               ".nnnnnnnnn.",
               "nnnnnnnnnnn",
               ".nnnnnnnnn.",
               "n.n.n.n.n.n"])
def zo_leo(cv):
    def f(t):
        t.fill_mask(m_polar(20, 20, lambda th: 13.5 + 2.2 * np.abs(np.cos(6 * th))), '#ffd23d')
        t.fill_mask(m_polar(20, 20, lambda th: 12 + 1.5 * np.abs(np.cos(6 * th + 0.5))), '#e0a800')
        t.disc(20, 21, 8.5, '#2b2a6b')
        t.rect(15, 18, 16, 19, '#ffffff'); t.rect(24, 18, 25, 19, '#ffffff')
        t.rect(19, 22, 21, 23, '#ffd23d'); t.hline(17, 23, 26, '#ffd23d')
        t.px(17, 25, '#ffd23d'); t.px(23, 25, '#ffd23d')
        t.disc(13, 13, 2, '#2b2a6b'); t.disc(27, 13, 2, '#2b2a6b')
    outlined(cv, f, '#c99300')

zo_virgo = Z(["y...y...y",
              "yy.yyy.yy",
              "y.y.y.y.y",
              "yy.yyy.yy",
              "y.y.y.y.y",
              "yy.yyy.yy",
              ".y..y..y.",
              "..y.y.y..",
              "...nyn...",
              "...nnn...",
              "..n.n.n.."])
zo_libra = Z(["......y......",
              "yyyyyyyyyyyyy",
              ".y....y....y.",
              "y.y...y...y.y",
              "y..y..y..y..y",
              "nnnnn.y.nnnnn",
              ".nnn..y..nnn.",
              "......y......",
              "....nnnnn...."])
zo_scorpio = Z(["........yy..",
                ".......y..y.",
                ".......y....",
                "......nn....",
                "yy...nn.....",
                "y.y.nnn.....",
                "..nnnnnn....",
                ".nnwnnnnn...",
                "..nnnnnn.y.y",
                ".n.n.n.n..yy"])
zo_sagittarius = Z(["........yyyy",
                    ".........yyy",
                    "..nn....y.yy",
                    ".n..n..y...y",
                    "n....ny.....",
                    "n....yn.....",
                    "n...y.n.....",
                    "n..y..n.....",
                    ".ny..n......",
                    "yyn.n.......",
                    "y.nn........"])
zo_capricorn = Z(["yy.......yy...",
                  ".yy.....yy....",
                  "..ynnnnny.....",
                  "..nnnnnnn.....",
                  ".nnwnnnwnn....",
                  "..nnnnnnn..nn.",
                  "...nnnnn..n..n",
                  "....nnn...n.n.",
                  "....yyy..nnn..",
                  ".....y.nnn....",
                  "......nn......"])
zo_aquarius = Z(["..nnnnn.....",
                 ".nnyyynn....",
                 "nnnnnnnnnc..",
                 "nnnnnnnnncc.",
                 ".nnnnnnn..c.",
                 "..nnnnn...c.",
                 "..........cc",
                 "cc.cc.cc.c.c",
                 ".cc.cc.cc..."])
zo_pisces = Z(["...nnnn...y",
               "..nwnnnnyyy",
               "...nnnn...y",
               "...........",
               "y...nnnn...",
               "yyynnnnwn..",
               "y...nnnn..."])

# ======================= MYTHICAL CREATURES =======================
my_anka = B([".....rr.........",
             "....rorr........",
             "...royrr........",
             "..royyorr...yy..",
             "..ryyyorr..yyyy.",
             "...ryyorr.yykyyO",
             "....ryorrryyyyy.",
             ".....rrrrrrryy..",
             "y...rrrrrrrrr...",
             "oy.orrrrrrrr....",
             "roooyrrrrr......",
             ".rryyoorr.......",
             "..rryy.oy.......",
             "....rr...y......"], {'r': '#e8304a', 'o': '#ff7a2e', 'y': '#ffd23d', 'O': '#c4651a'})
my_dragon = B(["...........E.E..",
               "...........eeee.",
               "..j.......eewke.",
               ".jjj......eeeeee",
               "jjjjj....eeeeyyr",
               "jjjjjj..eeee..ro",
               ".jjjjjjeeee.....",
               "..jjjjeeeeee....",
               "...E.eeeyyyee...",
               ".....eeyyyyyee..",
               "e...eeeyyyyyee..",
               "ee.eeeeeeeeeee..",
               ".eee..ee...ee..."], {'e': '#2fbf6a', 'E': '#1f8a4c', 'j': '#9ff0b8', 'y': '#ffd23d', 'r': '#ff5a3a', 'o': '#ffb02e'})

my_sahmeran = B(["..y.y.y..",
                 "..yyyyy..",
                 "..sssss..",
                 "..sksks..",
                 "..sssss..",
                 "...eee...",
                 "..eeEee..",
                 ".eeE.....",
                 ".eEeeeeE.",
                 "....EeeE.",
                 "..eeeeE.."])
my_unicorn = B(["......y...",
                ".....yy...",
                "...mwwy...",
                "..mpwwww..",
                ".mcwwkwww.",
                ".mwwwwwwww",
                ".ywwww.www",
                ".mwww.....",
                "..www....."], oc='#8a5a9a')
my_griffin = B(["...nnn.......",
                "..nwnnn......",
                "..nknnnyy....",
                "...nnnnyY....",
                "t..nnnn......",
                "tt.tttttt..tt",
                ".tttttttttt.t",
                "..tttttttt...",
                "..t.t..t.t..."], {'n': '#ffffff', 'w': '#ffffff', 't': '#e8a24a'})
my_pegasus = B(["...aa...........",
                "..aaaa......ww..",
                ".aaAaaa....wwww.",
                ".aAaaAaa..mwwkww",
                "..aAaaAaa.mwwwww",
                "...aaAaaamww....",
                "....aaaawwww....",
                "mm..wwwwwwww....",
                "mmmwwwwwwwww....",
                ".mmwwwwwwwwww...",
                "..mwwwwwwwwww...",
                "...ww.w...w.ww..",
                "...w..w...w..w..",
                "...y..y...y..y.."], {'w': '#f4f6ff', 'a': '#bfe6ff', 'A': '#7ab8e8', 'm': '#c86bff'})

my_kraken = B(["....pppp....",
               "...pppppp...",
               "..ppwppwpp..",
               "..ppkppkpp..",
               "...pppppp...",
               ".pp.pppp.pp.",
               "p..p.pp.p..p",
               "p.p..pp..p.p",
               ".p..p..p..p."], {'p': '#8a4ac8', 'w': '#ffffff'})
my_tepegoz = B(["..nnnnnnn..",
                ".nnnnnnnnn.",
                "nssssssssn.",
                "sssswwwssss",
                "sssw kwsss s".replace(' ', ''),
                "sssswwwssss",
                "sssssssssss",
                ".ssrrrrrss.",
                "..sswwwss..",
                "...sssss..."])

# ======================= THE EGG CLUB — the Sunday, stage by stage =======================
eg_doors = B(["nnnnnnnnnn",
              "nllllllNNn",
              "nlllllNttn",
              "nllllNtttn",
              "nlllNttttn",
              "nlllNttytn",
              "nlllNttttn",
              "nlllNttttn",
              "nllllNtttn",
              "nnnnnnnnnn"], {'l': '#fff6b0'})
eg_crack = B(["....yyy....",
              "...yllyy...",
              "..yllyyyy..",
              ".yyyyyyyyy.",
              "ykykykykyky",
              "kykykykykyk",
              "yyyyyyyyyyy",
              ".yyyyyyyYy.",
              "..yyyyyYY..",
              "...YYYYY..."])
eg_nest = B(["...ww.cc.ww...",
             "..wwwcccwwww..",
             "..wwwcccwwww..",
             ".nNnNnNnNnNnN.",
             "nNnnNnnNnnNnNn",
             ".nnnnnnnnnnnn.",
             "..NnNnNnNnNn.."], {'c': '#9ad0ff'})
eg_incubate = B(["......yy......",
                 ".....yyyy.....",
                 ".....yyyy.....",
                 "..gggggggggg..",
                 "..gccccccccg..",
                 "..gcckcckccg..",
                 "..gccccccccg..",
                 "..gggggggggg..",
                 ".dddddddddddd.",
                 "dddddddddddddd"], {'c': '#5ef0d0'})
eg_pizza = B(["nnnnnnnnnnnn",
              "tttttttttttt",
              ".yyryyyyryy.",
              ".yyyyyyyyyy.",
              "..yyyryyyy..",
              "..yyyyyyyy..",
              "...yyryyy...",
              "....yyyy....",
              ".....yy.....",
              ".....y......"])
eg_hatch = B(["....yyy.....",
              "...yyyyy....",
              "...ykyky....",
              "...yyooy....",
              "..yyyyyyy...",
              ".YkYYkYYkY..",
              ".YYkYkYkYY..",
              ".YYYYYYYYY..",
              "..YYYYYYY...",
              "...YYYYY...."], {'Y': '#f5b82e'})
eg_afterglow = B(["........yyy.",
                  ".......yyy..",
                  "......yyy...",
                  "......yyy...",
                  ".......yyy..",
                  "........yyy.",
                  ".xx...x.....",
                  ".xx..xxx.xx.",
                  "xxxx.xxxxxx.",
                  "xyxxxxyxxyxx",
                  "xxxxxxxxxxxx"], {'x': '#3a3560'})
eg_golden = B(["....yyyy....",
               "...yllyyy...",
               "..yllyyyyy..",
               "..ylyyyyyy..",
               ".yyyyyyyyyy.",
               ".yyyyyyyyYy.",
               ".yyyyyyyyYy.",
               "..yyyyyyYY..",
               "...yyyyYY...",
               "....YYYY...."])

COLLECTIONS = [
    dict(slug='08_zodiac', name='Zodiac', shape_name='die-cut · starry navy & gold',
         stickers=[('koc', zo_aries), ('boga', zo_taurus), ('ikizler', zo_gemini), ('yengec', zo_cancer),
                   ('aslan', zo_leo), ('basak', zo_virgo), ('terazi', zo_libra), ('akrep', zo_scorpio),
                   ('yay', zo_sagittarius), ('oglak', zo_capricorn), ('kova', zo_aquarius), ('balik', zo_pisces)]),
    dict(slug='09_mythical', name='Mythical Creatures', shape_name='die-cut',
         stickers=[('anka', my_anka), ('ejderha', my_dragon), ('sahmeran', my_sahmeran), ('tek_boynuz', my_unicorn),
                   ('griffin', my_griffin), ('pegasus', my_pegasus), ('kraken', my_kraken), ('tepegoz', my_tepegoz)]),
    dict(slug='10_eggclub', name='The Egg Club', shape_name='die-cut · one Sunday, stage by stage',
         stickers=[('doors', eg_doors), ('crack', eg_crack), ('nest', eg_nest), ('incubate', eg_incubate),
                   ('pizza', eg_pizza), ('hatch', eg_hatch), ('afterglow', eg_afterglow), ('golden_egg', eg_golden)]),
]

if __name__ == '__main__':
    for c in COLLECTIONS:
        render_collection(c)
