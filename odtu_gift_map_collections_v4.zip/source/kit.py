"""Shared toolkit for the ODTÜ Gift Map sticker collections (non-badge shapes)."""
import math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from stickers import hexc, dilate

S = 40          # canvas size in pixels
PAD = 4
SCALE = 12

PAL = {
    'k': '#1a1424', 'x': '#2b2140', 'z': '#141018',
    'w': '#ffffff', 'g': '#c9d1e0', 'G': '#8a93a6', 'd': '#4a5060',
    'r': '#e8484f', 'R': '#a3222b', 'o': '#ff9a3d', 'O': '#c4651a',
    'y': '#ffd23d', 'Y': '#c99300', 'l': '#fff6b0',
    'e': '#3ddc84', 'E': '#1f8a4c', 'b': '#4da3ff', 'B': '#2a5fc0',
    'c': '#6fd0ff', 'C': '#1d9aa8', 'p': '#c86bff', 'P': '#7a3cc0',
    'n': '#a0642e', 'N': '#6b3f1a', 't': '#e8c08a', 'T': '#c8955a',
    's': '#ffcf9e', 'S': '#e0a070', 'm': '#ff8fb8', 'M': '#d9578a',
    'v': '#2f6b4f', 'f': '#fbefd5', 'a': '#9ad0ff', 'h': '#5a3418',
    'u': '#2e8b57', 'U': '#174a2e', 'q': '#ffb38a', 'j': '#b0f0c8',
}

def col(c):
    if isinstance(c, tuple):
        return c
    if c.startswith('#'):
        return hexc(c)
    return hexc(PAL[c])

# ---------------- fonts ----------------
F3 = {
    'A': ["010", "101", "111", "101", "101"], 'B': ["110", "101", "110", "101", "110"],
    'C': ["011", "100", "100", "100", "011"], 'D': ["110", "101", "101", "101", "110"],
    'E': ["111", "100", "110", "100", "111"], 'F': ["111", "100", "110", "100", "100"],
    'G': ["011", "100", "101", "101", "011"], 'H': ["101", "101", "111", "101", "101"],
    'I': ["111", "010", "010", "010", "111"], 'J': ["001", "001", "001", "101", "010"],
    'K': ["101", "101", "110", "101", "101"], 'L': ["100", "100", "100", "100", "111"],
    'M': ["10001", "11011", "10101", "10001", "10001"],
    'N': ["1001", "1101", "1011", "1001", "1001"],
    'O': ["010", "101", "101", "101", "010"], 'P': ["110", "101", "110", "100", "100"],
    'Q': ["010", "101", "101", "110", "011"], 'R': ["110", "101", "110", "101", "101"],
    'S': ["011", "100", "010", "001", "110"], 'T': ["111", "010", "010", "010", "010"],
    'U': ["101", "101", "101", "101", "111"], 'V': ["101", "101", "101", "101", "010"],
    'W': ["10001", "10001", "10101", "11011", "10001"],
    'X': ["101", "101", "010", "101", "101"], 'Y': ["101", "101", "010", "010", "010"],
    'Z': ["111", "001", "010", "100", "111"],
    'e': ["000", "010", "111", "100", "011"], 'u': ["000", "000", "101", "101", "011"],
    'i': ["1", "0", "1", "1", "1"],
    '0': ["111", "101", "101", "101", "111"], '1': ["010", "110", "010", "010", "111"],
    '2': ["110", "001", "010", "100", "111"], '3': ["110", "001", "010", "001", "110"],
    '4': ["101", "101", "111", "001", "001"], '5': ["111", "100", "110", "001", "110"],
    '6': ["011", "100", "111", "101", "111"], '7': ["111", "001", "010", "010", "010"],
    '8': ["111", "101", "111", "101", "111"], '9': ["111", "101", "111", "001", "110"],
    '=': ["000", "111", "000", "111", "000"], '+': ["000", "010", "111", "010", "000"],
    '-': ["000", "000", "111", "000", "000"], ':': ["0", "1", "0", "1", "0"],
    '!': ["1", "1", "1", "0", "1"], '?': ["110", "001", "010", "000", "010"],
    '.': ["0", "0", "0", "0", "1"], '/': ["001", "001", "010", "100", "100"],
    ' ': ["0", "0", "0", "0", "0"], '#': ["01010", "11111", "01010", "11111", "01010"],
}
F5 = {  # 5x7 big glyphs
    '0': ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
    '1': ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
    '2': ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
    '3': ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
    '4': ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
    '5': ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
    '6': ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
    '7': ["11111", "00001", "00010", "00100", "01000", "01000", "01000"],
    '8': ["01110", "10001", "10001", "01110", "10001", "10001", "01110"],
    '9': ["01110", "10001", "10001", "01111", "00001", "00010", "01100"],
    'A': ["01110", "10001", "10001", "11111", "10001", "10001", "10001"],
    'C': ["01111", "10000", "10000", "10000", "10000", "10000", "01111"],
    'G': ["01111", "10000", "10000", "10011", "10001", "10001", "01111"],
    'S': ["01111", "10000", "10000", "01110", "00001", "00001", "11110"],
    'U': ["10001", "10001", "10001", "10001", "10001", "10001", "01110"],
    'O': ["01110", "10001", "10001", "10001", "10001", "10001", "01110"],
    'H': ["10001", "10001", "10001", "11111", "10001", "10001", "10001"],
    'F': ["11111", "10000", "10000", "11110", "10000", "10000", "10000"],
    'e': ["00000", "00000", "01110", "10001", "11111", "10000", "01110"],
    'u': ["00000", "00000", "10001", "10001", "10001", "10011", "01101"],
    ':': ["0", "1", "1", "0", "1", "1", "0"],
}

def tw(s, font=F3):
    return sum(len(font[c][0]) for c in s) + len(s) - 1

# ---------------- canvas ----------------
class Cv:
    def __init__(self):
        self.a = np.zeros((S, S, 4), dtype=np.uint8)

    def px(self, x, y, c):
        x, y = int(round(x)), int(round(y))
        if 0 <= x < S and 0 <= y < S:
            self.a[y, x] = col(c)

    def clear(self, x, y):
        if 0 <= x < S and 0 <= y < S:
            self.a[y, x] = 0

    def rect(self, x0, y0, x1, y1, c):
        for y in range(int(y0), int(y1) + 1):
            for x in range(int(x0), int(x1) + 1):
                self.px(x, y, c)

    def hline(self, x0, x1, y, c):
        self.rect(x0, y, x1, y, c)

    def vline(self, x, y0, y1, c):
        self.rect(x, y0, x, y1, c)

    def line(self, x0, y0, x1, y1, c):
        x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), int(round(y1))
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy; x0 += sx
            if e2 <= dx:
                err += dx; y0 += sy

    def polyline(self, pts, c):
        for p, q in zip(pts, pts[1:]):
            self.line(*p, *q, c)

    def disc(self, cx, cy, r, c):
        for y in range(int(cy - r - 1), int(cy + r + 2)):
            for x in range(int(cx - r - 1), int(cx + r + 2)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.3:
                    self.px(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(cy - ry - 1), int(cy + ry + 2)):
            for x in range(int(cx - rx - 1), int(cx + rx + 2)):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0:
                    self.px(x, y, c)

    def fill_mask(self, m, c):
        self.a[m] = col(c)

    def sparkle(self, x, y, c, big=False):
        self.px(x, y, c)
        for d in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            self.px(x + d[0], y + d[1], c)
            if big:
                self.px(x + 2 * d[0], y + 2 * d[1], c)

    def stamp(self, rows, x, y, remap=None):
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch in '. ':
                    continue
                if remap and ch in remap:
                    ch = remap[ch]
                self.px(x + i, y + j, ch)

    def stampc(self, rows, cx=20, cy=20, remap=None):
        w = max(len(r) for r in rows)
        self.stamp(rows, int(round(cx - w / 2)), int(round(cy - len(rows) / 2)), remap)

    def text(self, s, x, y, c, font=F3):
        for ch in s:
            g = font[ch]
            for j, row in enumerate(g):
                for i, bit in enumerate(row):
                    if bit == '1':
                        self.px(x + i, y + j, c)
            x += len(g[0]) + 1

    def textc(self, s, cx, y, c, font=F3):
        self.text(s, int(round(cx - tw(s, font) / 2)), y, c, font)

def outlined(cv, fn, oc='k'):
    tmp = Cv()
    fn(tmp)
    m = tmp.a[..., 3] > 0
    ring = dilate(m, 1) & ~m
    cv.a[ring] = col(oc)
    cv.a[m] = tmp.a[m]

def sprite(cv, rows, cx=20, cy=20, remap=None, oc='k'):
    """ASCII sprite with automatic 1px outer outline."""
    outlined(cv, lambda t: t.stampc(rows, cx, cy, remap), oc)

# ---------------- masks ----------------
YY, XX = np.mgrid[0:S, 0:S]

def m_ellipse(cx, cy, rx, ry):
    return ((XX - cx) / rx) ** 2 + ((YY - cy) / ry) ** 2 <= 1.0

def m_disc(cx, cy, r):
    return (XX - cx) ** 2 + (YY - cy) ** 2 <= r * r + 0.3

def m_rect(x0, y0, x1, y1):
    return (XX >= x0) & (XX <= x1) & (YY >= y0) & (YY <= y1)

def m_rrect(x0, y0, x1, y1, r):
    m = m_rect(x0, y0, x1, y1)
    for cx, cy in ((x0 + r, y0 + r), (x1 - r, y0 + r), (x0 + r, y1 - r), (x1 - r, y1 - r)):
        corner = m_rect(min(cx, x0 + r) if cx < (x0 + x1) / 2 else cx, 0, 0, 0)
    out = m.copy()
    for (cx, cy, sx, sy) in ((x0 + r, y0 + r, -1, -1), (x1 - r, y0 + r, 1, -1),
                             (x0 + r, y1 - r, -1, 1), (x1 - r, y1 - r, 1, 1)):
        zone = ((XX - cx) * sx > 0) & ((YY - cy) * sy > 0)
        out &= ~(zone & ((XX - cx) ** 2 + (YY - cy) ** 2 > r * r + 0.5))
    return out

def m_poly(pts):
    """Even-odd point-in-polygon test at pixel centres."""
    m = np.zeros((S, S), dtype=bool)
    n = len(pts)
    for y in range(S):
        for x in range(S):
            inside = False
            j = n - 1
            for i in range(n):
                xi, yi = pts[i]; xj, yj = pts[j]
                if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi + 1e-9) + xi:
                    inside = not inside
                j = i
            m[y, x] = inside
    return m

def m_polar(cx, cy, rfun):
    r = np.hypot(XX - cx, YY - cy)
    th = np.arctan2(YY - cy, XX - cx)
    return r <= rfun(th)

def edge_of(m):
    return m & ~(np.roll(m, 1, 0) & np.roll(m, -1, 0) & np.roll(m, 1, 1) & np.roll(m, -1, 1))

def frame(cv, m, fill, edge=None, hi=None):
    cv.fill_mask(m, fill)
    if hi:   # light inner highlight along top-left edge
        sh = m & ~np.roll(m, 1, 0)
        cv.fill_mask(np.roll(sh, 1, 0) & m, hi)
    if edge:
        cv.fill_mask(edge_of(m), edge)

# ---------------- export ----------------
def finish(cv, path):
    art = np.zeros((S + 2 * PAD, S + 2 * PAD, 4), dtype=np.uint8)
    art[PAD:PAD + S, PAD:PAD + S] = cv.a
    mask = art[..., 3] > 0
    rim = dilate(mask, 2)
    edge = dilate(rim, 1)
    out = np.zeros_like(art)
    sh = np.zeros_like(edge); sh[1:, 1:] = edge[:-1, :-1]
    out[sh] = (40, 30, 60, 90)
    out[edge] = hexc('#2b2140')
    out[rim] = hexc('#ffffff')
    out[mask] = art[mask]
    img = Image.fromarray(out, 'RGBA')
    img.resize((img.width * SCALE, img.height * SCALE), Image.NEAREST).save(path)
    return img

FONT_B = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
FONT_R = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'

def sheet(rows, path, s=4):
    """rows: list of (title, subtitle, [img x4])."""
    bw = rows[0][2][0].width * s
    lw, gap, rh = 420, 16, bw + 24
    Wt = lw + 4 * (bw + gap) + gap
    Ht = len(rows) * rh + gap
    bg = Image.new('RGBA', (Wt, Ht), hexc('#eef2ec'))
    d = ImageDraw.Draw(bg)
    fb, fr = ImageFont.truetype(FONT_B, 26), ImageFont.truetype(FONT_R, 18)
    for i, (title, sub, imgs) in enumerate(rows):
        y = gap + i * rh
        if i % 2:
            d.rectangle([0, y - 8, Wt, y + rh - 8], fill=hexc('#e3eae1'))
        d.text((24, y + bw // 2 - 34), title, font=fb, fill=(43, 33, 64, 255))
        yy = y + bw // 2 + 2
        for line in wrap(sub, 38):
            d.text((24, yy), line, font=fr, fill=(90, 90, 110, 255)); yy += 22
        for j, im in enumerate(imgs):
            big = im.resize((im.width * s, im.height * s), Image.NEAREST)
            bg.alpha_composite(big, (lw + gap + j * (bw + gap), y))
    bg.save(path)

def wrap(t, n):
    words, lines, cur = t.split(), [], ''
    for w in words:
        if len(cur) + len(w) + 1 > n:
            lines.append(cur); cur = w
        else:
            cur = (cur + ' ' + w).strip()
    if cur:
        lines.append(cur)
    return lines

def render(collections, outdir, sheet_path):
    os.makedirs(outdir, exist_ok=True)
    rows = []
    for c in collections:
        imgs = []
        for i, (sname, fn) in enumerate(c['stickers']):
            cv = Cv()
            c['shape'](cv)
            fn(cv)
            if c.get('post'):
                c['post'](cv)
            slug = c['slug']
            imgs.append(finish(cv, os.path.join(outdir, f"{slug}__{i + 1}_{sname}.png")))
        rows.append((c['name'], c['shape_name'] + ' · ' + c['theme'], imgs))
    sheet(rows, sheet_path)
