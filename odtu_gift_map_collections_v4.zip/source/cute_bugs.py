"""Cute, slightly smaller bugs for the Bug Jar (big glossy eyes, blush)."""
from kit2 import *

R = {'g': '#ffffff', 'w': '#d8f0ff', 'm': '#ff8fb8'}

def bug(rows, extra=None, cy=23):
    def f(cv):
        r = dict(R); r.update(extra or {})
        sprite(cv, rows, 19.5, cy, r)
    return f

bee = bug(["...k.....k...",
           "....k...k....",
           ".ww.yyyyy.ww.",
           "wwwyyyyyyywww",
           "wwygkyyygkyww",
           ".wykkyyykkyw.",
           "..ymyyyyymy..",
           "..kkkkkkkkk..",
           "..yyyyyyyyy..",
           "...kkkkkkk...",
           "....yyyyy....",
           "......k......"])

ladybug = bug(["....k...k....",
               ".....k.k.....",
               "....kkkkk....",
               "...kgkkkgk...",
               "...kkkkkkk...",
               ".rrrrrkrrrrr.",
               "rrkkrrkrrkkrr",
               "rrkkrrkrrkkrr",
               "rrrrrrkrrrrrr",
               "rrrkkrkrkkrrr",
               ".rrkkrkrkkrr.",
               "..rrrrkrrrr..",
               "....rrkrr...."])

beetle = bug(["...k.....k...",
              "....k...k....",
              "....eeeee....",
              "...egkeegke..",
              "...ekkeekke..",
              "...emeeeeme..",
              "..EEEEEEEEE..",
              ".EjjEEEEEEEE.",
              ".EjEEEEEEEEE.",
              ".EEEEEEEEEEE.",
              "..EEEEEEEEE..",
              "...EEEEEEE..."], {'e': '#3ddc84', 'E': '#1fb070', 'j': '#b8ffe0'})

firefly = bug(["...k.....k...",
               "....k...k....",
               "..ww.ddd.ww..",
               ".wwwdddddwww.",
               ".wwdgkdgkdww.",
               "..ddkkdkkdd..",
               "...dmddmdd...",
               "....ddddd....",
               "...lllllll...",
               "..lyyyyyyyl..",
               "..lyyyyyyyl..",
               "...lllllll..."], {'d': '#5a4a8a'})

butterfly = bug(["k...........k",
                 ".k.........k.",
                 "mmmm..k..mmmm",
                 "mppmm.n.mmppm",
                 "mppmm.n.mmppm",
                 ".mmmmgngmmmm.",
                 "..mmmknkmmm..",
                 "..ccc.n.ccc..",
                 ".cccc.n.cccc.",
                 ".cyc..n..cyc.",
                 "..c.......c.."], {'m': '#ff8fb8', 'p': '#ffffff', 'c': '#c86bff', 'n': '#5a3a2a'})

dragonfly = bug(["....bbb....",
                 "...bgkbgk..",
                 "...bkkbkk..",
                 "ww..bbb..ww",
                 "wwwwwCwwwww",
                 ".wwwwCwwww.",
                 "wwwwwCwwwww",
                 "ww...C...ww",
                 ".....C.....",
                 ".....C.....",
                 ".....C....."], {'b': '#4da3ff', 'w': '#d8f4ff', 'C': '#1d9aa8'})

caterpillar = bug(["..........k.k",
                   "...........k.",
                   "..........eee",
                   ".........egkge",
                   "..ee..ee.ekkke",
                   ".eeeeeeeeemeee",
                   "eEeeEeeEeeeee.",
                   ".eeeeeeeeeee..",
                   "..k.k..k.k...."], {'e': '#7be09a', 'E': '#3ddc84'})

ant = bug(["..k.....k....",
           "...k...k.....",
           "...nnnnn.....",
           "..ngknngk....",
           "..nkknnkk....",
           "..nnmnnmn....",
           "...nnnnn.....",
           "....nnn.nnnn.",
           "...nnnnnnnnnn",
           "..k.k.k.nnnn.",
           ".k..k..k....."], {'n': '#c4651a'})

STICKERS = [('firefly', firefly), ('bee', bee), ('ladybug', ladybug), ('beetle', beetle),
            ('butterfly', butterfly), ('dragonfly', dragonfly), ('caterpillar', caterpillar), ('ant', ant)]
