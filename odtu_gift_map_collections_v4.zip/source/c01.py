"""Batch 1 — METU & campus collections (1–10)."""
import math
import numpy as np
from kit import *

# =============== 1. ODTÜ 70. Yıl — rosette =================
def sh_rosette(cv):
    for pts in ([(13, 24), (18, 26), (15, 38), (12.5, 35), (9, 38)],
                [(27, 24), (22, 26), (25, 38), (27.5, 35), (31, 38)]):
        frame(cv, m_poly(pts), '#ffd23d', '#c99300')
    m = m_polar(20, 16, lambda th: 13 + 1.4 * np.cos(14 * th))
    frame(cv, m, '#c8102e', '#8c0b20')
    frame(cv, m_disc(20, 16, 9.6), '#e2304a', '#ffd23d')

def r70_70(cv):
    cv.text('70', 15, 11, '#8c0b20', F5); cv.text('70', 14, 10, '#ffd23d', F5)
    cv.textc('YIL', 20, 19, '#ffffff')
    cv.px(10, 9, '#ffffff'); cv.px(30, 22, '#ffffff')

def r70_1956(cv):
    sprite(cv, ["..ee.ee..",
                ".eEEeEEe.",
                "..eeNee..",
                "....N....",
                "..nnnnn.."], 20, 12)
    cv.textc('1956', 20.5, 18, '#ffffff')

def r70_cake(cv):
    sprite(cv, ["..y....y..",
                "..l....l..",
                "..r....r..",
                "..r....r..",
                "mmmmmmmmmm",
                "mwmmwmmwmm",
                "ffffffffff",
                "mmmmmmmmmm",
                "ffffffffff",
                "MMMMMMMMMM"], 20, 16)

def r70_fireworks(cv):
    for (cx, cy, r, c1, c2) in ((17, 13, 5, '#ffd23d', '#ffffff'), (24, 19, 3, '#6fd0ff', '#ffffff')):
        for k in range(8):
            a = k * math.pi / 4
            for d in range(2, r + 1):
                cv.px(cx + d * math.cos(a), cy + d * math.sin(a), c1 if d < r else c2)
        cv.px(cx, cy, c2)
    cv.sparkle(13, 21, '#ff8fb8')

# =============== 2. Campus Landmarks — postage stamp =================
def sh_stamp(cv):
    m = m_rect(6, 4, 33, 35)
    for x in range(7, 34, 3):
        m &= ~m_disc(x, 4, 1.2); m &= ~m_disc(x, 35, 1.2)
    for y in range(5, 35, 3):
        m &= ~m_disc(6, y, 1.2); m &= ~m_disc(33, y, 1.2)
    frame(cv, m, '#fbefd5', '#d9c49a')
    cv.rect(9, 7, 30, 27, '#9ad0ff')

def scene_frame(cv, label):
    cv.hline(9, 30, 27, '#2b2140'); cv.vline(9, 7, 27, '#2b2140'); cv.vline(30, 7, 27, '#2b2140')
    cv.hline(9, 30, 7, '#2b2140')
    cv.textc(label, 20, 29, '#6b3f12')

def lm_eymir(cv):
    cv.rect(10, 8, 29, 15, '#bfe6ff')
    cv.disc(25, 11, 2, '#fff27a')
    for x in range(10, 30):
        h = int(17 - 3 * math.sin((x - 10) / 19 * math.pi) - (1 if x % 7 < 3 else 0))
        cv.vline(x, h, 19, '#5bbf6a')
    cv.rect(10, 20, 29, 26, '#4da3ff')
    for x in range(11, 29, 4):
        cv.hline(x, x + 1, 22 + (x % 3), '#bfe6ff')
    cv.hline(14, 19, 23, '#a0642e'); cv.hline(15, 18, 24, '#6b3f1a')   # rowboat
    cv.vline(16, 20, 22, '#6b3f1a')
    for x in (11, 12, 27, 28):                                         # reeds
        cv.vline(x, 18, 21, '#2e8b57')
    scene_frame(cv, 'EYMIR')

def lm_devrim(cv):
    cv.rect(10, 8, 29, 13, '#bfe6ff')
    for i, c in enumerate(('#c9d1e0', '#8a93a6', '#c9d1e0', '#8a93a6')):
        cv.rect(10, 13 + i, 29, 13 + i, c)
    cv.rect(10, 17, 29, 26, '#3ddc84')
    cv.rect(10, 17, 29, 17, '#ffffff')
    cv.vline(19, 18, 26, '#ffffff'); cv.vline(20, 18, 26, '#ffffff')
    for y in range(19, 25):
        cv.px(16 + abs(y - 21.5) // 2 * 0, y, '#3ddc84')
    cv.disc(19.5, 21.5, 2.5, '#ffffff'); cv.disc(19.5, 21.5, 1.5, '#3ddc84')
    for x in (10, 29):
        cv.vline(x, 9, 13, '#4a5060'); cv.px(x, 8, '#fff27a')
    scene_frame(cv, 'DEVRIM')

def lm_orman(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    cv.rect(10, 22, 29, 26, '#7fbf6a')
    for (x, base, h, c) in ((13, 23, 10, '#2e8b57'), (18, 24, 13, '#1d5e3a'), (23, 23, 9, '#2e8b57'),
                            (27, 24, 11, '#1d5e3a'), (11, 25, 6, '#1d5e3a')):
        for j in range(h):
            half = j // 3 + (j % 3 == 2)
            cv.hline(x - half, x + half, base - h + j, c)
        cv.vline(x, base, base + 1, '#6b3f1a')
    scene_frame(cv, 'ORMAN')

def lm_a1(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    cv.rect(10, 21, 29, 26, '#8a93a6')
    cv.vline(19, 22, 26, '#ffffff'); cv.vline(20, 22, 26, '#ffffff')
    cv.rect(11, 13, 14, 22, '#c9d1e0'); cv.rect(25, 13, 28, 22, '#c9d1e0')
    cv.rect(11, 12, 28, 13, '#c8102e')
    cv.textc('ODTU', 20, 15, '#c8102e')
    cv.px(26 - 4, 14, '#c8102e'); cv.px(24 - 4 + 4, 14, '#c8102e')
    cv.hline(15, 23, 20, '#ffffff'); cv.hline(15, 23, 20, '#e8484f')
    for x in range(15, 24, 2):
        cv.px(x, 20, '#ffffff')
    scene_frame(cv, 'A1')

# =============== 3. Kantin — tea glass (ince belli) =================
def sh_teaglass(cv):
    frame(cv, m_ellipse(20, 34, 16, 3.2), '#ffffff', '#c9d1e0')
    left = [(8, 3), (9, 8), (11, 13), (14, 18), (13, 22), (11, 27), (10, 32)]
    right = [(40 - x, y) for (x, y) in reversed(left)]
    m = m_poly(left + right)
    frame(cv, m, '#c0501f', '#7a2e10')
    cv.fill_mask(m & (YY <= 5), '#f4ead8')
    cv.fill_mask(m & (YY == 6), '#e8a070')
    for y in range(8, 30):
        cv.px(12 + (y < 18) * (y - 8) // 4 - (y >= 18) * 0, y, '#e8804a') if False else None
    cv.vline(12, 9, 13, '#e8804a'); cv.vline(13, 14, 17, '#e8804a'); cv.vline(13, 23, 28, '#e8804a')

def k_simit(cv):
    def f(t):
        t.disc(20, 18, 7, '#b8702e')
        t.disc(19, 17, 5.5, '#d18a3e')
        for y in range(10, 27):
            for x in range(12, 29):
                if (x - 20) ** 2 + (y - 18) ** 2 <= 2.6 ** 2:
                    t.clear(x, y)
        for (x, y) in ((15, 13), (18, 12), (23, 12), (25, 15), (26, 19), (14, 19), (16, 23), (21, 24), (24, 22), (17, 15)):
            t.px(x, y, '#fbefd5')
    outlined(cv, f)

def k_tost(cv):
    def f(t):
        t.rect(12, 12, 28, 23, '#c8955a')
        t.rect(13, 13, 27, 22, '#e8c08a')
        for y in range(13, 23):
            for x in range(13, 28):
                if (x + y) % 4 == 0:
                    t.px(x, y, '#a0642e')
        t.rect(12, 12, 28, 23, '#c8955a') if False else None
        for x in range(14, 27, 3):
            t.vline(x, 24, 25 if x % 2 else 26, '#ffd23d')
        t.hline(13, 27, 23, '#ffd23d')
    outlined(cv, f)

def k_ayran(cv):
    sprite(cv, ["bbbbbbbbbbbb",
                "BBBBBBBBBBBB",
                ".wwwwwwwwww.",
                ".wbbwwwwbbw.",
                ".wwwwwwwwww.",
                "..wwwwwwww..",
                "..wwbbbbww..",
                "..wwwwwwww..",
                "...wwwwww...",
                "...wwwwww..."], 20, 18)

def k_pogaca(cv):
    def f(t):
        t.ellipse(20, 19, 8.5, 6, '#c47a2c')
        t.ellipse(19.5, 18, 7.5, 4.8, '#e8a24a')
        t.ellipse(18, 16.5, 4, 2, '#ffc070')
        for (x, y) in ((15, 18), (18, 15), (22, 17), (24, 20), (17, 21), (21, 21), (13, 20), (26, 18)):
            t.px(x, y, '#1a1424')
    outlined(cv, f)

# =============== 4. Campus Animals — paw print =================
def sh_paw(cv):
    m = m_ellipse(20, 26, 12.5, 10)
    for (cx, cy) in ((7.5, 12.5), (15, 7), (25, 7), (32.5, 12.5)):
        m |= m_ellipse(cx, cy, 3.8, 4.6)
    frame(cv, m, '#f2b8a0', '#b06a50')
    cv.ellipse(20, 26, 11, 8.5, '#ffd2c0')

def an_dog(cv):
    sprite(cv, ["NN........NN",
                "NNy......NNN",
                "NNNttttttNNN",
                ".Nttttttttn.",
                ".tkttttttkt.",
                ".tttttttttt.",
                "..tttkktttt.",
                "..ttmmmmtt..",
                "...ttmmtt...",
                "....tttt...."], 20, 26)

def an_cat(cv):
    sprite(cv, ["o..........o",
                "oo........oo",
                "ooOoooooOooo",
                "oooooooooooo",
                "oekooooooeko",
                "oooooooooooo",
                "wwwoommoowww",
                "owwwwwwwwwwo",
                ".oowwwwwwoo."], 20, 26)

def an_duck(cv):
    sprite(cv, ["....uuu.....",
                "...uuuuu....",
                "...ukuuuoo..",
                "...uuuuu....",
                "....ww......",
                ".nnnnnnnn...",
                "nnnnTTnnnnn.",
                "nnTTTnnnnnn.",
                ".nnnnnnnnn.."], 20, 25)
    cv.hline(11, 14, 31, '#4da3ff'); cv.hline(24, 28, 31, '#4da3ff')

def an_squirrel(cv):
    sprite(cv, [".ooo.........",
                "ooooo...o....",
                "oOooo..ooo...",
                "oOooo.ookoo..",
                ".oOoo.oooooo.",
                "..oOoooooo...",
                "...oooootoo..",
                "....oooootn..",
                "....oo..oo..."], 20, 26)

# =============== 5. ODTÜ Forest — leaf =================
def sh_leaf(cv):
    m = m_disc(8, 8, 23) & m_disc(32, 32, 23)
    cv.line(6, 34, 10, 30, '#6b3f1a'); cv.line(5, 34, 9, 30, '#6b3f1a')
    frame(cv, m, '#5bbf6a', '#2e7d4a')
    cv.line(9, 31, 31, 9, '#8fe09a')

def fo_cone(cv):
    sprite(cv, ["..E..E...",
                "...EE....",
                "...nn....",
                "..nTTn...",
                ".nTnnTn..",
                ".TnTTnT..",
                "nTnnnnTn.",
                ".TnTTnT..",
                ".nTnnTn..",
                "..nTTn...",
                "...nn...."], 20, 20)

def fo_acorn(cv):
    sprite(cv, ["....N.....",
                "..hhhhhh..",
                ".hNhNhNhh.",
                "hhhhhhhhhh",
                ".tttttttt.",
                ".tTttttTt.",
                "..tttttt..",
                "...tttt...",
                "....tt...."], 20, 20)

def fo_mushroom(cv):
    sprite(cv, ["...rrrrrr...",
                "..rrwrrrwrr.",
                ".rrrrrrrrrrr",
                ".rwrrrwrrrwr",
                "...ffffff...",
                "....ffff....",
                "....ffff....",
                "...ffffff..."], 20, 20)

def fo_hedgehog(cv):
    sprite(cv, ["..N.N.N.....",
                ".NnNnNnN....",
                "NnNnNnNnN...",
                "nNnNnNnNtt..",
                "NnNnNnNttkt.",
                ".nNnNnttttk.",
                "..tt..tt...."], 20, 20)

# =============== 6. Bahar Şenliği — ticket stub =================
def sh_ticket(cv):
    m = m_rrect(3, 9, 36, 30, 2) & ~m_disc(3, 19.5, 3.2) & ~m_disc(36, 19.5, 3.2)
    frame(cv, m, '#ff8fb8', '#c25a85')
    cv.fill_mask(m & (XX >= 28), '#ffd23d')
    cv.fill_mask(edge_of(m) & (XX >= 28), '#c99300')
    for y in range(10, 30, 2):
        cv.px(27, y, '#ffffff')
    for i, ch in enumerate('26'):
        cv.text(ch, 30, 14 + i * 7, '#6b3f12')

def bs_guitar(cv):
    sprite(cv, ["....dd....",
                "....NN....",
                "....nn....",
                "....nn....",
                "...tttt...",
                "..tttttt..",
                "..ttkktt..",
                "...tkkt...",
                ".tttttttt.",
                "tttttttttt",
                "ttttNNtttt",
                ".tttttttt.",
                "..tttttt.."], 15, 19.5)

def bs_cotton(cv):
    sprite(cv, ["..mmmm....",
                ".mmwmmmm..",
                "mmmmmmMmm.",
                "mmMmmmmmm.",
                ".mmmmMmm..",
                "..mmmmm...",
                "....g.....",
                "....g.....",
                "....g.....",
                "....g....."], 15, 19)

def bs_balloons(cv):
    for (cx, cy, c, ch) in ((11, 14, '#4da3ff', '#bfe0ff'), (19, 13, '#ffd23d', '#fff6b0'), (15, 18, '#3ddc84', '#b0f0c8')):
        def f(t, cx=cx, cy=cy, c=c, ch=ch):
            t.ellipse(cx, cy, 3, 3.8, c); t.px(cx - 1, cy - 2, ch); t.px(cx, cy + 4, c)
        outlined(cv, f)
    for (x0, y0) in ((11, 19), (19, 18), (15, 23)):
        cv.line(x0, y0, 15, 27, '#ffffff')

def bs_sun(cv):
    def f(t):
        t.disc(15, 19.5, 6, '#ffd23d')
        for k in range(8):
            a = k * math.pi / 4
            t.px(15 + 8 * math.cos(a), 19.5 + 8 * math.sin(a), '#ffd23d')
        t.rect(10, 18, 13, 19, '#1a1424'); t.rect(16, 18, 19, 19, '#1a1424'); t.hline(13, 16, 18, '#1a1424')
        t.hline(13, 17, 22, '#c4651a'); t.px(12, 21, '#c4651a'); t.px(18, 21, '#c4651a')
    outlined(cv, f)

# =============== 7. Exam Season — sticky note =================
def sh_sticky(cv):
    m = m_rect(6, 7, 33, 34) & ~((XX + YY) > 33 + 34 - 7)
    frame(cv, m, '#ffe066', '#c9a400')
    fold = m_poly([(33, 27.5), (26.5, 34), (26.5, 27.5)])
    frame(cv, fold, '#f0c830', '#c9a400')
    cv.rect(15, 4, 24, 8, '#d8ecff')

def ex_coffee(cv):
    sprite(cv, ["..w..w..",
                "...w..w.",
                "gggggggg",
                "wwwwwwww",
                ".wwwwww.",
                ".nnnnnn.",
                ".nnnnnn.",
                "..wwww..",
                "..wwww.."], 19.5, 20)

def ex_calc(cv):
    rows = ["dddddddddd",
            "djjjjjjjjd",
            "djjjjkkjjd",
            "dddddddddd"]
    rows += ["dgdgdgdgdd", "dddddddddd"] * 3
    rows[-2] = "dgdgdgdrdd"
    sprite(cv, rows, 19.5, 20)

def ex_moon(cv):
    def f(t):
        t.disc(17, 21, 7, '#fff27a')
        for y in range(12, 30):
            for x in range(9, 27):
                if (x - 20.5) ** 2 + (y - 18.5) ** 2 <= 6 ** 2:
                    t.clear(x, y)
        t.px(13, 21, '#1a1424'); t.px(14, 22, '#c99300')
    outlined(cv, f)
    cv.text('Z', 22, 11, '#2a5fc0'); cv.text('Z', 26, 15, '#4da3ff')

def ex_aa(cv):
    for k in range(0, 360, 6):
        a = math.radians(k)
        cv.px(19.5 + 9.5 * math.cos(a), 20.5 + 7.5 * math.sin(a), '#e8484f')
    cv.text('AA', 14, 17, '#e8484f', F5)

# =============== 8. Clubs — shield =================
def sh_shield(cv):
    pts = [(7, 5), (33, 5), (33, 17), (31, 24), (27, 30), (20, 35), (13, 30), (9, 24), (7, 17)]
    m = m_poly(pts)
    frame(cv, m, '#1f2a63', '#ffd23d')
    cv.fill_mask(m & (XX > 20) & ~edge_of(m), '#2b3a85')
    cv.hline(8, 32, 6, '#ffd23d')

def cl_mountain(cv):
    def f(t):
        for j in range(12):
            t.hline(20 - j, 20 + j, 13 + j, '#8a93a6')
        for j in range(4):
            t.hline(20 - j, 20 + j, 13 + j, '#ffffff')
        for j in range(6):
            t.hline(12 - j // 1 + 0, 12 + j, 19 + j, '#c9d1e0') if False else None
    outlined(cv, f)
    cv.vline(20, 7, 12, '#ffffff'); cv.rect(21, 7, 24, 9, '#e8484f')

def cl_camera(cv):
    sprite(cv, [".ddd........",
                "dddddddddddd",
                "dggggkkggggd",
                "dgggkbbkgggd",
                "dggkbcbbkggd",
                "dggkbbbbkggd",
                "dgggkbbkgggd",
                "dggggkkggggd",
                "dddddddddddd"], 20, 18)

def cl_masks(cv):
    happy = [".yyyyy.", "yyyyyyy", "ykyyyky", "yyyyyyy", "ykyyyky", "yykkkyy", ".yyyyy.", "..yyy.."]
    sad = [".ccccc.", "ccccccc", "ckcccck", "ccccccc", "cckkkcc", "ckcccck", ".ccccc.", "..ccc.."]
    sprite(cv, sad, 23, 20)
    sprite(cv, happy, 16, 16)

def cl_telescope(cv):
    def f(t):
        for off in (-1, 0, 1):
            t.line(12, 18 + off, 27, 11 + off, '#c9d1e0')
        t.line(12, 17, 27, 10, '#ffffff')
        t.rect(26, 9, 28, 13, '#4da3ff')
        t.line(19, 16, 15, 27, '#a0642e'); t.line(19, 16, 23, 27, '#a0642e'); t.line(19, 16, 19, 27, '#a0642e')
    outlined(cv, f)
    cv.sparkle(28, 22, '#fff27a'); cv.px(13, 10, '#ffffff')

# =============== 9. The Egg Club — egg =================
def sh_egg(cv):
    rx = np.where(YY < 21, 12.5 * 0.86, 12.5)
    m = ((XX - 19.5) / rx) ** 2 + ((YY - 21) / 16) ** 2 <= 1
    frame(cv, m, '#fbefd5', '#d9b26a')
    for (x, y) in ((11, 13), (27, 17), (12, 30), (28, 29), (20, 7)):
        cv.px(x, y, '#e8d2a0')

def eg_crack(cv):
    def f(t):
        t.ellipse(19.5, 18, 6, 7.5, '#f5b82e'); t.ellipse(18, 16, 3, 3.5, '#ffe28a')
    outlined(cv, f)
    cv.polyline([(13, 17), (15, 15), (17, 18), (19, 15), (21, 18), (23, 15), (25, 17)], '#7a4606')
    cv.textc('CRACK', 20, 28, '#6b3f12')

def eg_nest(cv):
    def f(t):
        t.ellipse(15.5, 16, 2.5, 3, '#ffffff'); t.ellipse(20, 15, 2.5, 3, '#9ad0ff'); t.ellipse(24.5, 16, 2.5, 3, '#ffffff')
        t.ellipse(20, 20, 9, 3.5, '#a0642e')
        for x in range(11, 30, 2):
            t.px(x, 19 + (x % 4 == 1), '#6b3f1a')
        t.hline(13, 27, 22, '#6b3f1a')
    outlined(cv, f)
    cv.textc('NEST', 20, 28, '#6b3f12')

def eg_pizza(cv):
    sprite(cv, ["nnnnnnnnnnn",
                "ttttttttttt",
                ".yyryyyyry.",
                ".yyyyyyyyy.",
                "..yyyryyy..",
                "..yyyyyyy..",
                "...yryyy...",
                "...yyyyy...",
                "....yyy....",
                "....yy.....",
                ".....y....."], 20, 18)
    cv.textc('PIZZA', 20, 28, '#6b3f12')

def eg_hatch(cv):
    def f(t):
        t.disc(20, 14, 4, '#ffe24a'); t.px(18, 13, '#1a1424'); t.px(22, 13, '#1a1424')
        t.hline(19, 21, 15, '#ff9a3d')
        t.ellipse(20, 21, 6.5, 4.5, '#f5b82e')
        for x in range(14, 27):
            if (x // 2) % 2 == 0:
                t.clear(x, 17)
        t.hline(14, 26, 17, (0, 0, 0, 0)) if False else None
    outlined(cv, f)
    cv.polyline([(13, 18), (15, 16), (17, 18), (19, 16), (21, 18), (23, 16), (25, 18), (27, 16)], '#7a4606')
    cv.textc('HATCH', 20, 28, '#6b3f12')

# =============== 10. Riddle Missions — puzzle piece =================
def sh_puzzle(cv):
    m = m_rect(7, 10, 29, 32) | m_disc(18, 7.5, 3.8) | m_disc(32, 21, 3.8)
    m &= ~m_disc(6.5, 21, 3.4)
    frame(cv, m, '#7a3cc0', '#4a1f80')
    cv.fill_mask(m & (YY == 11) & (XX > 8) & (XX < 28), '#a06ae0')

def rd_question(cv):
    sprite(cv, [".yyyyy.",
                "yyY.yyy",
                "....yyY",
                "...yyY.",
                "..yyY..",
                "..yyY..",
                ".......",
                "..yyY..",
                "..yyY.."], 18.5, 21)

def rd_magnifier(cv):
    def f(t):
        t.disc(16, 18, 5.5, '#c9d1e0')
        t.disc(16, 18, 4, '#bfe6ff'); t.px(14, 16, '#ffffff'); t.px(15, 15, '#ffffff')
        for off in (0, 1):
            t.line(20 + off, 22, 25 + off, 27, '#a0642e')
    outlined(cv, f)

def rd_key(cv):
    sprite(cv, [".yyy.........",
                "yyYyy........",
                "yY.Yyyyyyyyyy",
                "yyYyy....yY.y",
                ".yyy.....yY.y"], 18.5, 21)

def rd_map(cv):
    def f(t):
        t.rect(10, 13, 27, 28, '#e8c08a')
        for x in range(10, 28, 3):
            t.clear(x, 13); t.clear(x + 1, 28)
        t.vline(15, 14, 27, '#c8955a'); t.vline(21, 14, 27, '#c8955a')
    outlined(cv, f)
    for (x, y) in ((12, 26), (14, 24), (16, 23), (18, 21), (19, 19), (21, 18)):
        cv.px(x, y, '#6b3f1a')
    cv.line(22, 15, 25, 18, '#e8484f'); cv.line(25, 15, 22, 18, '#e8484f')

COLLECTIONS = [
    dict(slug='01_odtu70', name='ODTÜ 70. Yıl', shape_name='Rosette medal',
         theme='METU turns 70 (1956–2026)', shape=sh_rosette,
         stickers=[('70', r70_70), ('1956', r70_1956), ('cake', r70_cake), ('fireworks', r70_fireworks)]),
    dict(slug='02_landmarks', name='Campus Landmarks', shape_name='Postage stamp',
         theme='Eymir, Devrim, the forest, Gate A1', shape=sh_stamp,
         stickers=[('eymir', lm_eymir), ('devrim', lm_devrim), ('orman', lm_orman), ('a1', lm_a1)]),
    dict(slug='03_kantin', name='Kantin Classics', shape_name='Tea glass',
         theme='simit, tost, ayran, poğaça', shape=sh_teaglass,
         stickers=[('simit', k_simit), ('tost', k_tost), ('ayran', k_ayran), ('pogaca', k_pogaca)]),
    dict(slug='04_animals', name='Campus Animals', shape_name='Paw print',
         theme='METU dogs & cats, Eymir ducks, squirrels', shape=sh_paw,
         stickers=[('dog', an_dog), ('cat', an_cat), ('duck', an_duck), ('squirrel', an_squirrel)]),
    dict(slug='05_forest', name='ODTÜ Forest', shape_name='Leaf',
         theme='the student-planted forest', shape=sh_leaf,
         stickers=[('pinecone', fo_cone), ('acorn', fo_acorn), ('mushroom', fo_mushroom), ('hedgehog', fo_hedgehog)]),
    dict(slug='06_bahar', name='Bahar Şenliği', shape_name='Ticket stub',
         theme='spring festival', shape=sh_ticket,
         stickers=[('guitar', bs_guitar), ('cottoncandy', bs_cotton), ('balloons', bs_balloons), ('sun', bs_sun)]),
    dict(slug='07_exams', name='Exam Season', shape_name='Sticky note',
         theme='finals week survival', shape=sh_sticky,
         stickers=[('coffee', ex_coffee), ('calculator', ex_calc), ('allnighter', ex_moon), ('AA', ex_aa)]),
    dict(slug='08_clubs', name='Clubs & Societies', shape_name='Shield crest',
         theme='mountaineering, photo, theatre, astronomy', shape=sh_shield,
         stickers=[('mountaineering', cl_mountain), ('photo', cl_camera), ('theatre', cl_masks), ('astronomy', cl_telescope)]),
    dict(slug='09_eggclub', name='The Egg Club', shape_name='Egg',
         theme='a build Sunday: crack → nest → pizza → hatch', shape=sh_egg,
         stickers=[('crack', eg_crack), ('nest', eg_nest), ('pizza', eg_pizza), ('hatch', eg_hatch)]),
    dict(slug='10_riddles', name='Riddle Missions', shape_name='Puzzle piece',
         theme='earned by solving riddles', shape=sh_puzzle,
         stickers=[('question', rd_question), ('magnifier', rd_magnifier), ('key', rd_key), ('map', rd_map)]),
]

if __name__ == '__main__':
    render(COLLECTIONS, 'collections', 'sheet_batch1.png')
