"""Die-cut: Campus Animals (8) and Campus Transport (8). Drawn as chunky 2x pixel art."""
import math
from kit2 import *

def B(rows, remap=None, oc='k', cx=20, cy=20):
    return lambda cv: sprite(cv, big(rows), cx, cy, remap, oc)

# ======================= CAMPUS ANIMALS =======================
an_dog = B(["NN........NN",
            "NNy......NNN",
            "NNNttttttNNN",
            ".Nttttttttn.",
            ".tkttttttkt.",
            ".tttttttttt.",
            "..tttkktttt.",
            "..ttmmmmtt..",
            "...ttmmtt...",
            "....tttt...."])

an_cat = B(["o..........o",
            "oo........oo",
            "ooOoooooOooo",
            "oooooooooooo",
            "oekooooooeko",
            "oooooooooooo",
            "wwwoommoowww",
            "owwwwwwwwwwo",
            ".oowwwwwwoo."])

an_duck = B(["....uuu......",
             "...uuuuu.....",
             "...ukuuuoo...",
             "...uuuuu.....",
             "....ww.......",
             ".nnnnnnnn....",
             "nnnnTTnnnnn..",
             "nnTTTnnnnnn..",
             ".nnnnnnnnn...",
             "..cc....cc..."])

an_squirrel = B([".ooo.........",
                 "ooooo...o....",
                 "oOooo..ooo...",
                 "oOooo.ookoo..",
                 ".oOoo.oooooo.",
                 "..oOoooooo...",
                 "...oooootoo..",
                 "....oooootn..",
                 "....oo..oo..."])

an_hedgehog = B(["..N.N.N.....",
                 ".NnNnNnN....",
                 "NnNnNnNnN...",
                 "nNnNnNnNtt..",
                 "NnNnNnNttkt.",
                 ".nNnNnttttk.",
                 "..tt..tt...."])

an_magpie = B(["....kkk.......",
               "...kkwkk......",
               "...kkkkkG.....",
               "..kkkkk.......",
               ".kwwwkbk......",
               "kwwwwkbbk.....",
               "kwwwwkkbbbk...",
               ".kwwkkkkbbbbk.",
               "..kk..kkkkbbbk",
               "...G......kbbb",
               "...G.........."], {'b': '#2a5f9a'}, oc='#6a7080')

an_frog = B(["..kkk......kkk..",
             ".kwwwk....kwwwk.",
             ".kwkwk....kwkwk.",
             "kewwwekkkkewwwek",
             "keeeeeeeeeeeeeek",
             "keemeeeeeeeemeek",
             "keeeeeeeeeeeeeek",
             "kekkeeeeeeeekkek",
             ".keekkkkkkkkeek.",
             "..keeeeeeeeeek..",
             "...kkkkkkkkkk..."])

an_owl = B([".k........k.",
            ".kn......nk.",
            ".nnnnnnnnnn.",
            "nwwwnnnnwwwn",
            "wwkywnnwykww",
            "nwwwnoonwwwn",
            "nnnnnoonnnnn",
            "ntntnnnntntn",
            "nttttttttttn",
            ".nttttttttn.",
            "..nnnnnnnn..",
            "..o.o..o.o.."])

# ======================= CAMPUS TRANSPORT =======================
tr_ring = B([".rrrrrrrrrrrrr..",
             "rrcccrcccrcccrr.",
             "rrcccrcccrcccrrr",
             "rrrrrrrrrrrrrrrr",
             "rwwwwwwwwwwwwwwr",
             "rrrrrrrrrrrrrrry",
             ".rrkkkrrrrrkkkr.",
             "...kgk.....kgk..",
             "...kkk.....kkk.."])

tr_metro = B(["..gggggggg..",
              ".gggggggggg.",
              ".gccccccccg.",
              ".gccccccccg.",
              ".gccccccccg.",
              ".gggggggggg.",
              ".gyggrrggyg.",
              ".gggggggggg.",
              "..dd....dd..",
              "dddddddddddd"])

tr_dolmus = B([".yyyyyyyyyyy....",
               "yycccycccyccy...",
               "yycccycccycccy..",
               "yyyyyyyyyyyyyyyy",
               "ykkkkkkkkkkkkkky",
               "yyyyyyyyyyyyyyyw",
               ".yykkkyyyyykkky.",
               "...kgk.....kgk..",
               "...kkk.....kkk.."])

tr_taksi = B([".....kyk......",
              "....yyyyy.....",
              "...yccyccy....",
              "..yyccyccyy...",
              "yyyyyyyyyyyyyy",
              "ykykykykykykyw",
              "yyyyyyyyyyyyyy",
              ".ykkkyyyykkky.",
              "..kgk....kgk..",
              "..kkk....kkk.."])

def tr_bike(cv):
    def f(t):
        for cx in (11, 29):
            for y in range(S):
                for x in range(S):
                    d = math.hypot(x - cx, y - 25)
                    if 4.6 <= d <= 7:
                        t.px(x, y, '#2b2140' if d > 6 else '#8a93a6')
        for off in (0, 1):
            t.polyline([(11, 25 + off), (17, 15 + off), (26, 15 + off), (29, 25 + off)], '#e8484f')
            t.polyline([(17 + off, 15), (20 + off, 25), (26 + off, 15)], '#e8484f')
            t.line(11, 25 + off, 20, 25 + off, '#e8484f')
        t.rect(14, 12, 19, 13, '#2b2140')
        t.line(26, 15, 28, 10, '#4a5060'); t.rect(26, 9, 31, 10, '#2b2140')
        t.disc(20, 25, 1.6, '#4a5060')
    outlined(cv, f)

tr_scooter = B(["..........kk",
                "..........kg",
                "..........k.",
                ".........k..",
                ".........k..",
                "........k...",
                "........k...",
                ".ccccccck...",
                "kkk....kkk..",
                "kgk....kgk..",
                "kkk....kkk.."], {'c': '#3ddc84'})

tr_shoe = B(["....bbbbb.....",
             "...bwbwbbb....",
             "...bbwbwbbb...",
             "..bbbbbbbbbbb.",
             ".bbbbbbbbbbbbb",
             "wwwwwwwwwwwwww",
             "gggggggggggggg"])

tr_skate = B(["..pppppppppppp..",
              ".pmmpppppppppmp.",
              "pppppppppppppppp",
              ".pppppppppppppp.",
              "...ggg....ggg...",
              "..kyyk....kyyk..",
              "..kkkk....kkkk.."])

COLLECTIONS = [
    dict(slug='06_animals', name='Campus Animals', shape_name='die-cut',
         stickers=[('kopek', an_dog), ('kedi', an_cat), ('ordek', an_duck), ('sincap', an_squirrel),
                   ('kirpi', an_hedgehog), ('saksagan', an_magpie), ('kurbaga', an_frog), ('baykus', an_owl)]),
    dict(slug='07_transport', name='Campus Transport', shape_name='die-cut',
         stickers=[('ring', tr_ring), ('metro', tr_metro), ('dolmus', tr_dolmus), ('taksi', tr_taksi),
                   ('bisiklet', tr_bike), ('scooter', tr_scooter), ('yuruyus', tr_shoe), ('kaykay', tr_skate)]),
]

if __name__ == '__main__':
    for c in COLLECTIONS:
        render_collection(c)
