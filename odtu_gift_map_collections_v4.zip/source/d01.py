"""Framed collections: ODTÜ 70. Yıl, Campus Landmarks, Bug Jar — 8 each."""
import math
from kit2 import *
import c01, c05
import cute_bugs

# ---------- ODTÜ 70. Yıl (rosette) — 4 new ----------
def r70_balloons(cv):
    for (cx, cy, c, ch) in ((16, 14, '#ffd23d', '7'), (24, 14, '#ffffff', '0')):
        def f(t, cx=cx, cy=cy, c=c):
            t.ellipse(cx, cy, 3.6, 4.4, c); t.px(cx, cy + 5, c)
        outlined(cv, f, '#8c0b20')
        cv.text(ch, cx - 1, cy - 2, '#c8102e')
    cv.line(16, 20, 20, 24, '#ffffff'); cv.line(24, 20, 20, 24, '#ffffff')

def r70_gift(cv):
    def f(t):
        t.rect(14, 15, 26, 23, '#ffffff'); t.rect(13, 12, 27, 15, '#ffffff')
        t.rect(19, 12, 21, 23, '#ffd23d'); t.hline(13, 27, 13, '#ffd23d')
        t.stamp(["yy...yy", "y.y.y.y", ".yyyyy."], 17, 9)
    outlined(cv, f, '#8c0b20')

def r70_hat(cv):
    def f(t):
        for j in range(12):
            half = j // 2
            for x in range(20 - half, 21 + half):
                t.px(x, 10 + j, '#ffd23d' if ((x + j) // 2) % 2 else '#ffffff')
        t.disc(20, 9, 1.6, '#ff8fb8')
        t.hline(14, 26, 22, '#ffd23d')
    outlined(cv, f, '#8c0b20')

def r70_star(cv):
    pts = []
    for k in range(10):
        a = -math.pi / 2 + k * math.pi / 5
        r = 8 if k % 2 == 0 else 3.6
        pts.append((20 + r * math.cos(a), 16.5 + r * math.sin(a)))
    cv.fill_mask(m_poly(pts), '#ffd23d')
    cv.fill_mask(edge_of(m_poly(pts)), '#c99300')
    cv.px(18, 14, '#ffffff')

# ---------- Campus Landmarks (stamp) — 4 new ----------
sf = c01.scene_frame

def lm_amfi(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    for i, c in enumerate(('#c9d1e0', '#a8b0c0', '#c9d1e0', '#a8b0c0', '#c9d1e0')):
        cv.fill_mask(m_ellipse(19.5, 27, 10 - i * 0 + 0.5, 12 - i * 2) & ~m_ellipse(19.5, 27, 9.5, 10 - i * 2) & m_rect(10, 8, 29, 26), c)
    cv.fill_mask(m_ellipse(19.5, 27, 4.5, 3) & m_rect(10, 8, 29, 26), '#a0642e')
    sf(cv, 'AMFI')

def lm_carsi(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    cv.rect(10, 15, 29, 26, '#f4ead8')
    for i, c in enumerate(('#e8484f', '#3ddc84', '#4da3ff', '#ffd23d')):
        x = 10 + i * 5
        for xx in range(x, x + 5):
            cv.vline(xx, 13, 15, c if xx % 2 else '#ffffff')
        cv.rect(x + 1, 18, x + 3, 25, '#6b3f1a'); cv.rect(x + 1, 18, x + 3, 20, '#bfe6ff')
    sf(cv, 'CARSI')

def lm_yurt(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    for (x0, x1, top, c) in ((11, 18, 11, '#e8c08a'), (21, 28, 13, '#d8a870')):
        cv.rect(x0, top, x1, 26, c)
        for y in range(top + 2, 25, 3):
            for x in range(x0 + 1, x1, 2):
                cv.px(x, y, '#fff27a' if (x + y) % 5 == 0 else '#6a7fa0')
    cv.rect(10, 25, 29, 26, '#7fbf6a')
    sf(cv, 'YURT')

def lm_kkm(cv):
    cv.rect(10, 8, 29, 26, '#cfe9ff')
    cv.rect(10, 23, 29, 26, '#c9d1e0')
    cv.rect(12, 14, 27, 23, '#f4f4f8'); cv.rect(12, 14, 27, 15, '#8a93a6')
    for x in range(13, 27, 2):
        cv.vline(x, 17, 22, '#9ad0ff')
    for (x, c) in ((14, '#e8484f'), (20, '#c8102e'), (25, '#e8484f')):
        cv.vline(x, 9, 13, '#4a5060'); cv.rect(x + 1, 9, x + 3, 10, c)
    sf(cv, 'KKM')

# ---------- Bug Jar — 4 new ----------
def bg_butterfly(cv):
    sprite(cv, ["k.......k",
                ".k.....k.",
                "mmm.k.mmm",
                "mymmkmmym",
                "mmmmkmmmm",
                ".mmmkmmm.",
                ".cc.k.cc.",
                "cccck cccc".replace(' ', ''),
                ".cc...cc."], 19.5, 22, {'m': '#ff8fb8', 'y': '#ffd23d', 'c': '#c86bff'})

def bg_dragonfly(cv):
    sprite(cv, ["cc..k..cc",
                "ccc.k.ccc",
                ".cccecc..",
                "....e....",
                ".cccecc..",
                "ccc.e.ccc",
                "....e....",
                "....e....",
                "....e...."], 19.5, 22, {'c': '#bfe6ff', 'e': '#1d9aa8'}, oc='#2a5f80')

def bg_caterpillar(cv):
    def f(t):
        for i, x in enumerate(range(12, 27, 3)):
            t.disc(x, 24 - (1 if i % 2 else 0), 2, '#3ddc84' if i % 2 else '#7be09a')
        t.disc(28, 21, 2.4, '#3ddc84'); t.px(29, 20, '#1a1424')
        t.px(28, 18, '#1a1424'); t.px(30, 18, '#1a1424')
    outlined(cv, f)

def bg_ant(cv):
    sprite(cv, ["..k...k...",
                "...k.k....",
                "...kk.kkk.",
                "..kkkkkkkk",
                ".kkk.kk.kk",
                "k..k.k.k..",
                ".k..k.k.k."], 19.5, 22, {'k': '#4a2a1a'}, oc='#8ab8d8')


# ---------- bigger bugs (2x) ----------
def _bb(rows, remap=None, oc='k', cy=22):
    return lambda cv: sprite(cv, big(rows), 19.5, cy, remap, oc)

bee2 = _bb(["...ww.ww...", "...wwwww...", ".yykyykyy..", "kyykyykyyk.", ".yykyykyy..", "...k.k....."])
lady2 = _bb(["....kk....", "...kkkk...", ".rrrkkrrr.", "rrkrrkrkrr", "rrrrrkrrrr", "rkrrrkrrkr", ".rrrrkrrr.", "..rrrkrr.."])
beetle2 = _bb(["..k....k..", "...k..k...", "...eeee...", "..eEeeEe..", ".eEeccEee.", ".eEecceEe.", ".eEeeeeEe.", "..eEeeEe..", "...eeee..."],
              {'e': '#2fb07a', 'E': '#1d6b5c', 'c': '#8fffd8'})
fly2 = _bb(["k.......k", ".k.....k.", "mmm.k.mmm", "mymmkmmym", "mmmmkmmmm", ".mmmkmmm.", ".cc.k.cc.", "cccckcccc", ".cc...cc."],
           {'m': '#ff8fb8', 'y': '#ffd23d', 'c': '#c86bff'})
drag2 = _bb(["cc..k..cc", "ccc.k.ccc", ".cccecc..", "....e....", ".cccecc..", "ccc.e.ccc", "....e....", "....e....", "....e...."],
            {'c': '#bfe6ff', 'e': '#1d9aa8'}, '#2a5f80')
ant2 = _bb(["..k...k...", "...k.k....", "...kk.kkk.", "..kkkkkkkk", ".kkk.kk.kk", "k..k.k.k..", ".k..k.k.k."], {'k': '#4a2a1a'}, '#8ab8d8')

def firefly2(cv):
    cv.disc(19.5, 24, 8, '#fff6b0'); cv.disc(19.5, 24, 5.5, '#ffe24a')
    sprite(cv, big(["..ww.ww..", "..wkwkw..", "...kkk...", "...kyk...", "...yyy..."]), 19.5, 21, {'k': '#2b2140'}, '#8ab8d8')
    for (x, y) in ((12, 14), (27, 16), (12, 31), (27, 31)):
        cv.px(x, y, '#ffd23d')

COLLECTIONS = [
    dict(slug='01_odtu70', name='ODTÜ 70. Yıl', shape_name='Rosette medal (shared)', shape=c01.sh_rosette,
         stickers=[('70', c01.r70_70), ('1956', c01.r70_1956), ('cake', c01.r70_cake), ('fireworks', c01.r70_fireworks),
                   ('balloons', r70_balloons), ('gift', r70_gift), ('partyhat', r70_hat), ('star', r70_star)]),
    dict(slug='02_landmarks', name='Campus Landmarks', shape_name='Postage stamp (shared)', shape=c01.sh_stamp,
         stickers=[('eymir', c01.lm_eymir), ('devrim', c01.lm_devrim), ('orman', c01.lm_orman), ('a1', c01.lm_a1),
                   ('amfi', lm_amfi), ('carsi', lm_carsi), ('yurt', lm_yurt), ('kkm', lm_kkm)]),
    dict(slug='03_bugjar', name='Bug Jar', shape_name='Mason jar (shared)', shape=c05.sh_jar,
         stickers=cute_bugs.STICKERS),
]

if __name__ == '__main__':
    for c in COLLECTIONS:
        render_collection(c)
