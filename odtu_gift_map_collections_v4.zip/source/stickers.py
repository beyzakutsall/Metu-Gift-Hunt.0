"""Pixel-art sticker samples for the ODTÜ Gift Map.

Each sticker is drawn on a small pixel grid, then gets a die-cut sticker
border (white rim + dark outline + soft shadow) and is upscaled with
nearest-neighbour so the pixels stay crisp.
"""
import math
import numpy as np
from PIL import Image

W, H = 36, 40          # art canvas (pixels)
CX = 18
PAD = 4                # room for the sticker rim
SCALE = 12             # export scale -> 528 x 624 px

def hexc(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

class Canvas:
    def __init__(self):
        self.a = np.zeros((H, W, 4), dtype=np.uint8)

    def px(self, x, y, c):
        x, y = int(round(x)), int(round(y))
        if 0 <= x < W and 0 <= y < H:
            self.a[y, x] = hexc(c) if isinstance(c, str) else c

    def get(self, x, y):
        if 0 <= x < W and 0 <= y < H:
            return self.a[y, x]
        return None

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def hline(self, x0, x1, y, c):
        self.rect(x0, y, x1, y, c)

    def line(self, x0, y0, x1, y1, c):
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        while True:
            self.px(x0, y0, c)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy; x0 += sx
            if e2 <= dx:
                err += dx; y0 += sy

    def disc(self, cx, cy, r, c):
        for y in range(int(cy - r - 1), int(cy + r + 2)):
            for x in range(int(cx - r - 1), int(cx + r + 2)):
                if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.3:
                    self.px(x, y, c)

    def ellipse_ring(self, cx, cy, a, b, ang_deg, c):
        ang = math.radians(ang_deg)
        pts = []
        for i in range(73):
            t = 2 * math.pi * i / 72
            x = a * math.cos(t); y = b * math.sin(t)
            xr = cx + x * math.cos(ang) - y * math.sin(ang)
            yr = cy + x * math.sin(ang) + y * math.cos(ang)
            p = (int(round(xr)), int(round(yr)))
            if not pts or pts[-1] != p:
                pts.append(p)
        for p, q in zip(pts, pts[1:]):
            self.line(*p, *q, c)
        return pts

    def sparkle(self, x, y, c, big=False):
        self.px(x, y, c)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            self.px(x + dx, y + dy, c)
        if big:
            for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
                self.px(x + dx, y + dy, c)

    def outline_inside(self, mask, c):
        """Colour the boundary pixels of a boolean mask."""
        m = mask
        for y in range(H):
            for x in range(W):
                if not m[y, x]:
                    continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if not (0 <= xx < W and 0 <= yy < H) or not m[yy, xx]:
                        self.px(x, y, c)
                        break

def backdrop(cv, fill, ring, cy=16, r=15.5):
    cv.disc(CX - 0.5, cy, r, ring)
    cv.disc(CX - 0.5, cy, r - 1, fill)

# ---------- tiny 3x5 pixel font ----------
FONT = {
    'A': ["010", "101", "111", "101", "101"],
    'B': ["110", "101", "110", "101", "110"],
    'C': ["011", "100", "100", "100", "011"],
    'E': ["111", "100", "110", "100", "111"],
    'G': ["011", "100", "101", "101", "011"],
    'H': ["101", "101", "111", "101", "101"],
    'I': ["111", "010", "010", "010", "111"],
    'L': ["100", "100", "100", "100", "111"],
    'M': ["10001", "11011", "10101", "10001", "10001"],
    'O': ["010", "101", "101", "101", "010"],
    'P': ["110", "101", "110", "100", "100"],
    'S': ["011", "100", "010", "001", "110"],
    'U': ["101", "101", "101", "101", "111"],
    'W': ["10001", "10001", "10101", "11011", "10001"],
    'Y': ["101", "101", "010", "010", "010"],
    ' ': ["0", "0", "0", "0", "0"],
}

def text_width(s):
    return sum(len(FONT[ch][0]) for ch in s) + (len(s) - 1)

def draw_text(cv, s, x, y, c):
    for ch in s:
        g = FONT[ch]
        for j, row in enumerate(g):
            for i, bit in enumerate(row):
                if bit == '1':
                    cv.px(x + i, y + j, c)
        x += len(g[0]) + 1

def banner(cv, label, fill, dark, ink, y=31):
    tw = text_width(label)
    half = max(tw // 2 + 3, 9)
    x0, x1 = CX - half, CX + half - 1
    # folded ribbon tails
    cv.rect(x0 - 2, y + 2, x0, y + 8, dark)
    cv.rect(x1, y + 2, x1 + 2, y + 8, dark)
    cv.px(x0 - 2, y + 8, (0, 0, 0, 0)); cv.px(x1 + 2, y + 8, (0, 0, 0, 0))
    cv.px(x0 - 1, y + 7, dark); cv.px(x1 + 1, y + 7, dark)
    # main band
    cv.rect(x0 + 1, y, x1 - 1, y + 7, fill)
    cv.hline(x0 + 1, x1 - 1, y + 7, dark)
    draw_text(cv, label, CX - tw // 2, y + 2 - (0 if tw % 2 == 0 else 0), ink)

# ---------- sticker finishing ----------
def dilate(mask, r):
    out = mask.copy()
    h, w = mask.shape
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if abs(dx) + abs(dy) > r + (1 if r > 1 else 0):
                continue
            shifted = np.zeros_like(mask)
            ys = slice(max(0, dy), h + min(0, dy))
            yd = slice(max(0, -dy), h + min(0, -dy))
            xs = slice(max(0, dx), w + min(0, dx))
            xd = slice(max(0, -dx), w + min(0, -dx))
            shifted[ys, xs] = mask[yd, xd]
            out |= shifted
    return out

def finish(cv, name):
    art = np.zeros((H + 2 * PAD, W + 2 * PAD, 4), dtype=np.uint8)
    art[PAD:PAD + H, PAD:PAD + W] = cv.a
    mask = art[..., 3] > 0
    rim = dilate(mask, 2)
    edge = dilate(rim, 1)
    out = np.zeros_like(art)
    # soft shadow (offset 1,1)
    sh = np.zeros_like(edge)
    sh[1:, 1:] = edge[:-1, :-1]
    out[sh] = (40, 30, 60, 90)
    out[edge] = hexc('#2b2140')
    out[rim] = hexc('#ffffff')
    out[mask] = art[mask]
    img = Image.fromarray(out, 'RGBA')
    img.resize((img.width * SCALE, img.height * SCALE), Image.NEAREST).save(f'{name}.png')
    img.save(f'{name}_1x.png')
    return img

# =====================================================================
# 1) PHYSICS — atom wearing a Santa hat
# =====================================================================
def physics():
    cv = Canvas()
    backdrop(cv, '#1f2a63', '#3b4ea8')
    cy = 17
    orbit = '#6fd0ff'
    rings = [cv.ellipse_ring(CX, cy, 13, 5, ang, orbit) for ang in (0, 60, 120)]
    for ring, k in zip(rings, (0.12, 0.45, 0.80)):     # electrons
        x, y = ring[int(len(ring) * k)]
        cv.rect(x - 1, y - 1, x, y, '#fff27a')
        cv.px(x - 1, y - 1, '#ffffff')
    cv.disc(CX, cy, 4.2, '#0f1538')                   # nucleus
    cv.disc(CX, cy, 3.4, '#e8484f')
    for (dx, dy) in ((-2, -1), (1, -2), (-1, 1), (2, 1), (0, 3), (-3, 2), (2, -1)):
        cv.px(CX + dx, cy + dy, '#4b7bec')
    cv.px(CX - 2, cy - 2, '#ffb0b3'); cv.px(CX - 1, cy - 3, '#ffb0b3')
    red, red_d, white = '#d6202f', '#9b1622', '#ffffff'   # Santa hat
    for y, x0, x1 in ((8, 18, 19), (9, 17, 20), (10, 16, 21), (11, 15, 21), (12, 15, 22)):
        cv.hline(x0, x1, y, red); cv.px(x1, y, red_d)
    for (x, y) in ((20, 7), (21, 7), (22, 7), (23, 8), (24, 9)):
        cv.px(x, y, red)
    cv.px(22, 8, red_d)
    cv.rect(24, 10, 25, 11, white); cv.px(25, 11, '#cfd8ee')
    cv.rect(14, 13, 23, 14, white); cv.hline(14, 23, 14, '#cfd8ee')
    for (x, y) in ((8, 7), (27, 26)):
        cv.sparkle(x, y, '#bfe9ff')
    for (x, y) in ((11, 4), (29, 10), (6, 22), (24, 3)):
        cv.px(x, y, '#ffffff')
    banner(cv, 'PHYSICS', '#6fd0ff', '#2a86b8', '#14213d')
    return finish(cv, 'physics')

# =====================================================================
# 2) ELECTRICAL & ELECTRONICS — glowing LED under a fairy-light garland
# =====================================================================
def electrical():
    cv = Canvas()
    backdrop(cv, '#14213d', '#2b3d6b')
    wire = '#3a9a5c'
    pts = [(x, int(round(6 + 5 * (1 - ((x - 17.5) / 11.5) ** 2)))) for x in range(6, 30)]
    for p, q in zip(pts, pts[1:]):
        cv.line(*p, *q, wire)
    wy = dict(pts)
    for x, col in ((8, '#ff4d5e'), (12, '#3ddc84'), (22, '#4da3ff'), (27, '#c86bff')):
        y = wy[x]
        cv.hline(x, x + 1, y + 1, '#8a93a6')
        cv.rect(x, y + 2, x + 1, y + 4, col)
        cv.px(x, y + 2, '#ffffff')
    body, hi, sh = '#ffd23d', '#fff6b0', '#e0a400'
    top = 14
    cv.hline(16, 20, top, body)
    cv.hline(15, 21, top + 1, body)
    cv.rect(14, top + 2, 22, top + 7, body)
    for y in range(top + 2, top + 8):
        cv.px(22, y, sh)
    cv.px(21, top + 1, sh)
    cv.rect(15, top + 2, 15, top + 6, hi); cv.px(16, top + 1, hi)
    cv.rect(16, top + 5, 17, top + 7, '#c99300')        # anvil
    cv.rect(19, top + 4, 20, top + 7, '#c99300')        # post
    cv.px(18, top + 4, '#c99300')
    cv.rect(13, top + 8, 23, top + 9, sh)               # flange
    cv.hline(13, 23, top + 9, '#b88400')
    cv.rect(16, top + 10, 16, top + 15, '#b9c2d6')      # anode (long)
    cv.rect(20, top + 10, 20, top + 12, '#b9c2d6')      # cathode (bent)
    cv.px(21, top + 13, '#b9c2d6'); cv.px(22, top + 14, '#b9c2d6')
    cv.hline(12, 14, top + 13, '#ff4d5e'); cv.px(13, top + 12, '#ff4d5e'); cv.px(13, top + 14, '#ff4d5e')
    cv.hline(23, 25, top + 11, '#4da3ff')
    ray = '#fff27a'
    for (x0, y0, x1, y1) in ((11, 18, 9, 18), (25, 18, 27, 18), (12, 14, 10, 12),
                             (24, 14, 26, 12)):
        cv.line(x0, y0, x1, y1, ray)
    cv.px(18, 12, ray)
    cv.sparkle(28, 24, '#bfe9ff'); cv.sparkle(7, 24, '#bfe9ff')
    for (x, y) in ((17, 4), (5, 15), (31, 15)):
        cv.px(x, y, '#ffffff')
    banner(cv, 'EE', '#ffd23d', '#c99300', '#14213d')
    return finish(cv, 'electrical')

# =====================================================================
# 3) THE EGG CLUB — golden egg hatching a laptop (plus pizza)
# =====================================================================
def egg_club():
    cv = Canvas()
    backdrop(cv, '#fbefd5', '#e3c98f')
    ecx, ecy, rx, ry = CX - 0.5, 19, 8.5, 12.5
    gold, gold_hi, gold_sh, gold_ln, inner = '#f5b82e', '#ffe28a', '#d18b12', '#7a4606', '#fff7d6'

    def crack_y(x):                       # zig-zag crack (triangle wave)
        p = x % 4
        return 15 + (p if p <= 2 else 4 - p)

    def shade(x, y):
        nx = (x - ecx) / rx
        if nx < -0.4 and y < ecy + 3:
            return gold_hi
        if nx > 0.45 or y > ecy + 7:
            return gold_sh
        return gold
    # laptop rising out of the shell
    cv.rect(11, 5, 24, 16, '#2b2140')
    cv.rect(12, 6, 23, 15, '#5ef0d0')
    cv.hline(12, 23, 6, '#b8fff0')
    for (x, y) in ((15, 9), (14, 10), (15, 11), (21, 9), (22, 10), (21, 11),
                   (19, 8), (18, 9), (18, 10), (17, 11), (17, 12)):
        cv.px(x, y, '#1d6b5c')
    # bottom shell
    shell = np.zeros((H, W), dtype=bool)
    for y in range(H):
        for x in range(W):
            if ((x - ecx) / rx) ** 2 + ((y - ecy) / ry) ** 2 <= 1.0 and y >= crack_y(x):
                shell[y, x] = True
                cv.px(x, y, shade(x, y))
    cv.outline_inside(shell, gold_ln)
    # inner lip of the crack (pale shell interior)
    for x in range(W):
        y = crack_y(x) + 1
        if 0 <= y < H and shell[y, x] and shell[min(y + 1, H - 1), x]:
            l, r = shell[y, x - 1], shell[y, x + 1]
            if l and r:
                cv.px(x, y, inner)
    for (x, y) in ((14, 23), (21, 26), (17, 28), (22, 20)):
        cv.px(x, y, '#ffd66e')
    # flying shell fragments
    for (x0, y0) in ((26, 2), (6, 15)):
        for dx, dy in ((0, 0), (1, 0), (2, 0), (0, 1), (1, 1), (0, 2)):
            cv.px(x0 + dx, y0 + dy, gold)
        cv.px(x0, y0, gold_hi); cv.px(x0 + 2, y0, gold_ln); cv.px(x0, y0 + 2, gold_ln)
    # pizza slice
    crust, cheese, pep = '#c47a2c', '#ffd65c', '#d6202f'
    cv.hline(4, 9, 6, crust); cv.hline(4, 9, 7, '#e39a4a')
    for i, y in enumerate(range(8, 12)):
        cv.hline(4 + (i + 1) // 2, 9 - (i + 1) // 2, y, cheese)
    cv.px(5, 8, pep); cv.px(8, 8, pep); cv.px(6, 10, pep)
    cv.sparkle(29, 13, '#f2a900', big=False)
    cv.sparkle(28, 24, '#f2a900')
    cv.px(9, 25, '#f2a900'); cv.px(31, 8, '#f2a900')
    banner(cv, 'EGG CLUB', '#6b3f12', '#4a2a0a', '#fbefd5')
    return finish(cv, 'egg_club')

# =====================================================================
# 4) WELCOME — ODTÜ forest pine dressed for New Year, with a gift
# =====================================================================
def welcome():
    cv = Canvas()
    backdrop(cv, '#cfe6ff', '#9cc4f0')
    g, g_d, g_l, snow = '#2e8b57', '#1d5e3a', '#4fb878', '#ffffff'
    metu_red = '#c8102e'
    for y in range(26, H):               # snowy ground, clipped to the badge
        for x in range(W):
            if (x - (CX - 0.5)) ** 2 + (y - 16) ** 2 <= 14.5 ** 2:
                cv.px(x, y, '#f4f8ff' if y > 26 else '#e3ecfb')
    cv.rect(16, 24, 19, 28, '#7a4a25'); cv.rect(19, 24, 19, 28, '#5a3418')
    tiers = [(4, 12, 6), (8, 18, 9), (13, 25, 12)]
    tree = np.zeros((H, W), dtype=bool)
    for ay, by, hw in tiers:
        for y in range(ay, by + 1):
            half = int(round(hw * (y - ay) / (by - ay)))
            for x in range(CX - half - 1, CX + half + 1):
                tree[y, x] = True
    for y in range(H):
        for x in range(W):
            if tree[y, x]:
                c = g_d if x >= CX + 2 else (g_l if x <= CX - 4 and (x + y) % 5 == 0 else g)
                cv.px(x, y, c)
    cv.outline_inside(tree, '#174a2e')
    for ay, by, hw in tiers:
        for x in range(CX - hw - 1, CX + hw + 1):
            if (x % 3) != 1:
                cv.px(x, by, snow)
    for (x0, y0, x1, y1) in ((13, 10, 22, 14), (11, 16, 25, 20), (9, 22, 26, 23)):
        cv.line(x0, y0, x1, y1, '#ffd23d')
    for (x, y, c) in ((15, 13, metu_red), (21, 11, '#4da3ff'), (13, 19, '#ffd23d'),
                      (19, 17, metu_red), (24, 22, '#c86bff'), (16, 22, metu_red),
                      (10, 24, '#4da3ff'), (22, 19, '#ffd23d')):
        cv.px(x, y, c)
    cv.sparkle(CX - 1, 2, '#ffd23d'); cv.px(CX - 1, 2, '#fff6b0')
    # gift box (the app's "gift") in METU red
    cv.rect(23, 23, 30, 29, metu_red)
    cv.rect(23, 23, 30, 24, '#e2304a')
    cv.rect(26, 23, 27, 29, snow)
    cv.hline(23, 30, 25, snow)
    cv.px(25, 22, snow); cv.px(24, 21, snow); cv.px(28, 22, snow); cv.px(29, 21, snow)
    cv.rect(30, 25, 30, 29, '#9b0c23')
    for (x, y) in ((7, 8), (28, 6), (6, 16), (29, 15), (9, 3), (25, 2)):
        cv.px(x, y, '#ffffff')
    cv.sparkle(6, 12, '#ffffff')
    banner(cv, 'WELCOME', metu_red, '#8c0b20', '#ffffff')
    return finish(cv, 'welcome')

if __name__ == '__main__':
    imgs = [physics(), electrical(), egg_club(), welcome()]
    # preview sheet on a snowy-campus-map background
    s = 8
    gap = 6
    w = sum(i.width for i in imgs) + gap * (len(imgs) + 1)
    h = imgs[0].height + gap * 2
    bg = Image.new('RGBA', (w, h), hexc('#dfeee0'))
    px = bg.load()
    for y in range(h):
        for x in range(w):
            if (x // 4 + y // 4) % 2 == 0:
                px[x, y] = hexc('#d4e7d6')
    x = gap
    for im in imgs:
        bg.alpha_composite(im, (x, gap))
        x += im.width + gap
    bg.resize((w * s, h * s), Image.NEAREST).save('preview_sheet.png')
