"""Die-cut: Exam Season (8), Ankara (8), Seven Wonders of the Ancient World (7)."""
import math
from kit2 import *

def B(rows, remap=None, oc='k', cx=20, cy=20):
    return lambda cv: sprite(cv, big(rows), cx, cy, remap, oc)

def big2(cv, s, x, y, c, font=F5):
    for ch in s:
        g = font[ch]
        for j, row in enumerate(g):
            for i, bit in enumerate(row):
                if bit == '1':
                    cv.rect(x + 2 * i, y + 2 * j, x + 2 * i + 1, y + 2 * j + 1, c)
        x += 2 * len(g[0]) + 2

# ======================= EXAM SEASON =======================
ex_coffee = B(["...w..w....",
               "....w..w...",
               "ggggggggggg",
               "wwwwwwwwwww",
               ".wwwwwwwww.",
               ".nnnnnnnnn.",
               ".nnmnnnmnn.",
               ".nnnnnnnnn.",
               "..wwwwwww..",
               "..wwwwwww..",
               "...wwwww..."], oc='#4a3a3a')

ex_calc = B(["dddddddddd",
             "djjjjjjjjd",
             "djjjjkkjjd",
             "dddddddddd",
             "dgdgdgdgdd",
             "dddddddddd",
             "dgdgdgdgdd",
             "dddddddddd",
             "dgdgdgdrdd",
             "dddddddddd"])

ex_allnighter = B(["...yyyy.....",
                   "..yyy.....bb",
                   ".yyy.......b",
                   "yyy.......b.",
                   "yyy......bb.",
                   "yyy.........",
                   "yyyk........",
                   ".yyyy.....yy",
                   "..yyyyyyyyy.",
                   "....yyyyy..."], {'b': '#4da3ff'})

def ex_aa(cv):
    def f(t):
        t.rect(8, 4, 31, 36, '#ffffff')
        for y in range(8, 35, 3):
            t.hline(10, 29, y, '#cfe0f8')
        t.vline(12, 5, 35, '#ffb0b8')
        t.stamp(["ww", "w."], 30, 4, {'w': '#e0e6f0'})
    outlined(cv, f)
    big2(cv, 'AA', 9, 10, '#e8484f')
    cv.polyline([(11, 29), (16, 31), (24, 28), (30, 25)], '#e8484f')
    cv.polyline([(11, 30), (16, 32), (24, 29), (30, 26)], '#e8484f')

ex_books = B([".bbbbbbbbbbb.",
              ".bwwwwwwwwwB.",
              ".bbbbbbbbbbb.",
              "rrrrrrrrrrrr.",
              "rwwwwwwwwwwR.",
              "rrrrrrrrrrrr.",
              "..eeeeeeeeeee",
              "..ewwwwwwwwwE",
              "..eeeeeeeeeee"])

ex_highlighter = B(["..kkkk..",
                    "..kkkk..",
                    "..yyyy..",
                    ".yyyyyy.",
                    ".ylyyyy.",
                    ".ylyyyy.",
                    ".yyyyyy.",
                    ".yyyyyy.",
                    ".gggggg.",
                    "..gggg..",
                    "...yy...",
                    "...y...."], {'k': '#c99300'})

def ex_formula(cv):
    def f(t):
        t.rect(8, 5, 31, 35, '#fff6b0')
        for y in range(9, 34, 4):
            t.hline(10, 29, y, '#e8d880')
    outlined(cv, f)
    cv.text('F=MA', 11, 11, '#2a5fc0')
    cv.text('E=MC', 11, 18, '#e8484f'); cv.px(27, 17, '#e8484f'); cv.px(28, 17, '#e8484f'); cv.px(28, 18, '#e8484f')
    cv.text('V=IR', 11, 25, '#1f8a4c')

ex_energy = B([".gggggg.",
               "gGggggGg",
               "bbbbbbbb",
               "bbbbyybb",
               "bbbyybbb",
               "bbyyyyyb",
               "bbbbyybb",
               "bbbyybbb",
               "bbbbbbbb",
               "gGggggGg",
               ".gggggg."], {'b': '#7a3cc0'})

# ======================= ANKARA =======================
an_kale = B(["....r.........",
             "....rw........",
             "....k.........",
             "g.g.g...g.g.g.",
             "ggggg...ggggg.",
             "gGggg...ggGgg.",
             "ggggggggggggg.",
             "gGgggggkkgggGg",
             "ggggggkkkkgggg",
             "gggggkkkkkkggg"])

an_atakule = B(["....c....",
                "..ccccc..",
                ".cwcwcwc.",
                "ccccccccc",
                "...ggg...",
                "...gwg...",
                "...ggg...",
                "...gwg...",
                "...ggg...",
                "...gwg...",
                "..ggggg.."])

an_anitkabir = B(["..tttttttttttt..",
                  ".TTTTTTTTTTTTTT.",
                  ".tStStStStStStSt",
                  ".tStStStStStStSt",
                  ".tStStStStStStSt",
                  ".TTTTTTTTTTTTTT.",
                  "tttttttttttttttt",
                  "TTTTTTTTTTTTTTTT",
                  "tttttttttttttttt"], {'S': '#9a7a50'})

an_tiftik = B(["..t......t....",
               ".tt.....tt....",
               ".twwwwwwwt....",
               "wwkwwwkwww....",
               "wwwwwwwwwwwww.",
               ".wwmmwwwwwwwww",
               "..ww.wwwwwwwww",
               ".....ww.w..ww.",
               ".....ww.w..ww."], oc='#8a7a6a')

an_kedi = B(["w...w.......",
             "ww.ww.......",
             "wwwww.......",
             "bwwwo.......",
             "wwmww.......",
             ".www........",
             ".wwwww......",
             "wwwwwww...w.",
             "wwwwwwww..w.",
             "wwwwwwww.ww.",
             ".wwwwwwwww..",
             ".ww.ww......"], {'b': '#4da3ff', 'o': '#ffb02e'}, oc='#8a8aa0')

an_kugu = B(["..ww........",
             ".wwkw.......",
             ".wwwoo......",
             "..ww........",
             "..ww........",
             "...ww..wwww.",
             "...wwwwwwwww",
             "..wwwwwwwwww",
             "..wwwwwwwww.",
             "cccccccccccc"], oc='#6a8ac8')

an_armut = B([".....N.ee",
              ".....Neee",
              "....jjj..",
              "...jjjjj.",
              "...jjjjj.",
              "..jjjjjjj",
              ".jjjjjjjjj",
              ".jwjjjjjjj",
              ".jjjjjjjjj",
              "..jjjjjjj.",
              "...jjjjj.."], {'j': '#d8e050'})

an_hamamonu = B(["......nn......",
                 "....nnnnnn....",
                 "..nnnnnnnnnn..",
                 "nnnnnnnnnnnnnn",
                 ".wnwwwnwwwnww.",
                 ".wnwbwnwbwnww.",
                 ".wnwbwnwbwnww.",
                 ".nnnnnnnnnnnn.",
                 "..wwwwwwwwww..",
                 "..wbwnnnwbww..",
                 "..wwwnnnwwww..",
                 "..wwwnnnwwww.."], {'b': '#6fb0e0'})

# ======================= SEVEN WONDERS (ancient) =======================
sw_pyramid = B(["..........y.",
                "......t.....",
                ".....tTT....",
                "....ttTTT...",
                "...tttTTTT..",
                "..ttttTTTTT.",
                ".tttttTTTTTT",
                "tttttttTTTTT",
                "ssssssssssss"], {'s': '#e8c08a', 'T': '#c8955a', 't': '#f0d8a0'})

sw_gardens = B(["....eeee....",
                "....tttt....",
                "...eeeeee...",
                "...tEttEt...",
                "..eeeeeeee..",
                "..ttEttEtt..",
                ".eeeeeeeeee.",
                ".ttEttttEtt.",
                "tttttttttttt",
                "tttwwttwwttt"], {'t': '#e8c08a'})

sw_zeus = B(["....yyy.....",
             "...ysssy....",
             "...wwwww....",
             "..yywwwyy...",
             "..ywwwwwy.y.",
             ".nnywwwynny.",
             ".nwwwwwwwn..",
             ".nwwwwwwwn..",
             ".nnnwwwnnn..",
             ".nn.www.nn..",
             "nnnnnnnnnnn."], {'w': '#fbf3dc', 's': '#f0e0c0'})

sw_artemis = B(["......w......",
                "....wwwww....",
                "..wwwwwwwww..",
                "wwwwwwwwwwwww",
                "TTTTTTTTTTTTT",
                ".w.w.w.w.w.w.",
                ".w.w.w.w.w.w.",
                ".w.w.w.w.w.w.",
                ".w.w.w.w.w.w.",
                "TTTTTTTTTTTTT",
                "wwwwwwwwwwwww"], {'w': '#fbf6ec', 'T': '#d8c193'})

sw_mausoleum = B(["....y.y.....",
                  "....yyyy....",
                  "...TTTTTT...",
                  "..TTTTTTTT..",
                  ".TTTTTTTTTT.",
                  ".w.w.w.w.w..",
                  ".w.w.w.w.w..",
                  "wwwwwwwwwww.",
                  "TTTTTTTTTTT.",
                  "TTTTTTTTTTT.",
                  "TTTTTTTTTTT."], {'w': '#fbf6ec', 'T': '#d8c193'})

sw_colossus = B(["......o.",
                 ".....yoy",
                 ".....n..",
                 "..nnnn..",
                 "..nOOn..",
                 "...nn...",
                 "..nnnn..",
                 ".nnnnnn.",
                 ".n.nn...",
                 "...nn...",
                 "..n..n..",
                 ".n....n.",
                 "ggg..ggg"], {'n': '#c8803a', 'O': '#e8a050'})

sw_lighthouse = B(["....o....",
                   "...oyo...",
                   "...ggg...",
                   "...www...",
                   "...wbw...",
                   "..wwwww..",
                   "..wwbww..",
                   "..wwwww..",
                   ".wwwwwww.",
                   ".wwwbwww.",
                   ".wwwwwww.",
                   "ccccccccc"], {'w': '#f4ead8'})

COLLECTIONS = [
    dict(slug='11_exams', name='Exam Season', shape_name='die-cut',
         stickers=[('coffee', ex_coffee), ('calculator', ex_calc), ('all_nighter', ex_allnighter), ('AA', ex_aa),
                   ('books', ex_books), ('highlighter', ex_highlighter), ('formula_sheet', ex_formula), ('energy', ex_energy)]),
    dict(slug='12_ankara', name='Ankara', shape_name='die-cut',
         stickers=[('kale', an_kale), ('atakule', an_atakule), ('anitkabir', an_anitkabir), ('tiftik_keci', an_tiftik),
                   ('ankara_kedisi', an_kedi), ('kugulu_park', an_kugu), ('ankara_armudu', an_armut), ('hamamonu', an_hamamonu)]),
    dict(slug='13_seven_wonders', name='Seven Wonders of the Ancient World', shape_name='die-cut',
         stickers=[('giza_pyramid', sw_pyramid), ('hanging_gardens', sw_gardens), ('zeus_olympia', sw_zeus),
                   ('artemis_ephesus', sw_artemis), ('mausoleum_halicarnassus', sw_mausoleum),
                   ('colossus_rhodes', sw_colossus), ('lighthouse_alexandria', sw_lighthouse)]),
]

if __name__ == '__main__':
    for c in COLLECTIONS:
        render_collection(c)
