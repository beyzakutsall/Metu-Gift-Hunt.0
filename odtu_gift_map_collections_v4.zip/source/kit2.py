"""Rendering helpers for the final collections (variable size, framed or die-cut)."""
import os
from PIL import Image, ImageDraw, ImageFont
from kit import *

OUT = 'final'

def big(rows):
    """Double an ASCII sprite (each pixel -> 2x2)."""
    out = []
    for r in rows:
        rr = ''.join(ch * 2 for ch in r)
        out += [rr, rr]
    return out

def render_collection(c):
    d = os.path.join(OUT, c['slug'])
    os.makedirs(d, exist_ok=True)
    imgs = []
    for i, (name, fn) in enumerate(c['stickers']):
        cv = Cv()
        if c.get('shape'):
            c['shape'](cv)
        fn(cv)
        imgs.append((name, finish(cv, os.path.join(d, f'{i + 1:02d}_{name}.png'))))
    grid_sheet(c, imgs, os.path.join(OUT, f"sheet_{c['slug']}.png"))
    return imgs

def grid_sheet(c, imgs, path, s=4):
    n = len(imgs)
    cols = {12: 6, 7: 7}.get(n, 8 if n <= 8 else 6)
    bw = imgs[0][1].width * s
    gap, head = 18, 92
    rows = (n + cols - 1) // cols
    Wt = cols * (bw + gap) + gap
    Ht = head + rows * (bw + 30 + gap) + gap
    bg = Image.new('RGBA', (max(Wt, 900), Ht), hexc('#eef2ec'))
    d = ImageDraw.Draw(bg)
    fb, fr, fs = ImageFont.truetype(FONT_B, 34), ImageFont.truetype(FONT_R, 20), ImageFont.truetype(FONT_R, 17)
    d.text((gap + 6, 16), c['name'], font=fb, fill=(43, 33, 64, 255))
    d.text((gap + 6, 58), f"{n} stickers · {c['shape_name']}", font=fr, fill=(90, 90, 110, 255))
    for i, (name, im) in enumerate(imgs):
        r, k = divmod(i, cols)
        x, y = gap + k * (bw + gap), head + r * (bw + 30 + gap)
        bg.alpha_composite(im.resize((im.width * s, im.height * s), Image.NEAREST), (x, y))
        tw_ = d.textlength(name, font=fs)
        d.text((x + (bw - tw_) / 2, y + bw + 2), name, font=fs, fill=(70, 70, 90, 255))
    bg.save(path)


# ---------------- "fun" finish: no white rim, glossy bevel, richer colour ----------------
from PIL import ImageEnhance
import numpy as np

def _shift(m, dy, dx):
    out = np.zeros_like(m)
    h, w = m.shape
    ys, yd = slice(max(0, dy), h + min(0, dy)), slice(max(0, -dy), h + min(0, -dy))
    xs, xd = slice(max(0, dx), w + min(0, dx)), slice(max(0, -dx), w + min(0, -dx))
    out[ys, xs] = m[yd, xd]
    return out

def finish_fun(cv, path, glint=True):
    P = 3
    art = np.zeros((S + 2 * P, S + 2 * P, 4), dtype=np.uint8)
    art[P:P + S, P:P + S] = cv.a
    mask = art[..., 3] > 0
    # 1) richer colour
    img = Image.fromarray(art, 'RGBA')
    rgb = ImageEnhance.Color(img.convert('RGB')).enhance(1.25)
    rgb = ImageEnhance.Contrast(rgb).enhance(1.06)
    a = np.array(rgb).astype(np.int16)
    # 2) bevel: light top-left inner edge, darker bottom-right inner edge
    lum = a.sum(axis=2)
    interior = mask & (lum > 160)
    top = interior & ~_shift(interior, 1, 0)
    left = interior & ~_shift(interior, 0, 1)
    bot = interior & ~_shift(interior, -1, 0)
    right = interior & ~_shift(interior, 0, -1)
    hi = (top | left) & ~(bot | right)
    lo = (bot | right) & ~(top | left)
    a[hi] = a[hi] + (255 - a[hi]) * 45 // 100
    a[lo] = a[lo] * 78 // 100
    a = np.clip(a, 0, 255).astype(np.uint8)
    out = np.zeros_like(art)
    # 3) dark outline around the whole silhouette + soft offset shadow
    ring = dilate(mask, 1) & ~mask
    shadow = _shift(dilate(mask, 1), 2, 1) & ~dilate(mask, 1)
    out[shadow] = (30, 20, 50, 70)
    out[ring] = hexc('#1a1424')
    out[mask, :3] = a[mask]
    out[mask, 3] = 255
    # 4) a little collectible glint in the top-right empty space
    if glint:
        ys, xs = np.where(mask)
        gx, gy = xs.max() - 1, ys.min() + 1
        for (dx, dy) in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            x, y = gx + dx, gy + dy
            if 0 <= x < out.shape[1] and 0 <= y < out.shape[0]:
                out[y, x] = hexc('#ffffff')
        out[gy, gx] = hexc('#fff6b0')
    im = Image.fromarray(out, 'RGBA')
    im.resize((im.width * SCALE, im.height * SCALE), Image.NEAREST).save(path)
    return im

def render_collection(c):
    d = os.path.join(OUT, c['slug'])
    os.makedirs(d, exist_ok=True)
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    imgs = []
    for i, (name, fn) in enumerate(c['stickers']):
        cv = Cv()
        if c.get('shape'):
            c['shape'](cv)
        fn(cv)
        imgs.append((name, finish_fun(cv, os.path.join(d, f'{i + 1:02d}_{name}.png'))))
    grid_sheet(c, imgs, os.path.join(OUT, f"sheet_{c['slug']}.png"))
    return imgs
