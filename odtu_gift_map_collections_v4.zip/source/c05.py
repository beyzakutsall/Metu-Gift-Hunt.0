"""Batch 5 — nature, luck & friends (41–50)."""
import math
import numpy as np
from kit import *

# =============== 41. Engineering Wonders — hard hat =================
def sh_hardhat(cv):
    m = (m_ellipse(20, 23, 14, 15) & (YY <= 23)) | m_rrect(2, 22, 37, 27, 2)
    frame(cv, m, '#ffd23d', '#c99300')
    cv.fill_mask(m & (XX >= 18) & (XX <= 21) & (YY < 22) & ~edge_of(m), '#ffe68a')
    cv.fill_mask(m & (YY >= 26) & ~edge_of(m), '#e0aa10')

def ew_bridge(cv):
    c = '#2b2140'
    cv.vline(12, 9, 20, c); cv.vline(28, 9, 20, c)
    cv.polyline([(12, 9), (16, 15), (20, 17), (24, 15), (28, 9)], c)
    cv.hline(8, 32, 19, '#e8484f')
    for x in (15, 18, 21, 24):
        cv.vline(x, 15 + (x in (18, 21)) * 2, 18, '#8a6a10')

def ew_eiffel(cv):
    c = '#6b3f1a'
    cv.polyline([(20, 7), (17, 15), (14, 21)], c); cv.polyline([(20, 7), (23, 15), (26, 21)], c)
    cv.hline(17, 23, 14, c); cv.hline(15, 25, 18, c)
    cv.px(18, 20, c); cv.px(22, 20, c); cv.hline(18, 22, 19, c)
    cv.px(20, 6, c)

def ew_pyramid(cv):
    for j in range(11):
        cv.hline(20 - j, 20, 10 + j, '#e8a24a'); cv.hline(21, 20 + j, 10 + j, '#c47a2c')
    cv.hline(9, 31, 21, '#c8955a')

def ew_dam(cv):
    cv.rect(9, 10, 16, 20, '#4da3ff'); cv.hline(9, 16, 10, '#9ad0ff')
    for y in range(10, 21):
        cv.hline(17, 19 + (y - 10) // 3, y, '#8a93a6')
    for x in range(24, 31, 2):
        cv.vline(x, 18, 20, '#4da3ff')
    cv.hline(20, 31, 21, '#4da3ff')

# =============== 42. Dinosaurs — bone =================
def sh_bone(cv):
    m = m_rect(9, 15, 30, 25)
    for (cx, cy) in ((8, 14), (8, 26), (31, 14), (31, 26)):
        m |= m_disc(cx, cy, 5)
    frame(cv, m, '#fbf3dc', '#c8b58a')

def dn_trex(cv):
    sprite(cv, ["......eeeee.",
                ".....eewkeee",
                ".....eeeeeee",
                ".....eeewwww",
                "e...eeeee...",
                "ee.eeeeeEe..",
                ".eeeeeeeE...",
                "..eeeeee....",
                "...ee.ee....",
                "...e...ee..."], 19.5, 20)

def dn_trike(cv):
    sprite(cv, [".t.......t..",
                "..oo.t..oo..",
                "..ooooooooo.",
                ".oooookooooo",
                "oooooooooo..",
                "ooOoooooooo.",
                ".ooooooooo..",
                "..oo..oo....",
                "..oo..oo...."], 19.5, 20, {'o': '#c86bff', 'O': '#7a3cc0', 't': '#ffffff'})

def dn_ammonite(cv):
    def f(t):
        t.disc(19.5, 20, 6.5, '#e8a24a')
        pts = [(19.5 + (5.5 - k * 0.35) * math.cos(k * 0.6), 20 + (5.5 - k * 0.35) * math.sin(k * 0.6)) for k in range(16)]
        t.polyline([(round(x), round(y)) for x, y in pts], '#a0642e')
    outlined(cv, f)

def dn_footprint(cv):
    for (x0, y0, x1, y1) in ((19, 23, 13, 15), (20, 23, 20, 13), (21, 23, 27, 15)):
        for off in (0, 1):
            cv.line(x0 + off, y0, x1 + off, y1, '#6b3f1a')
    cv.ellipse(20, 24, 3, 2.2, '#6b3f1a')

# =============== 43. Ocean — fish =================
def sh_fish(cv):
    m = m_ellipse(17, 20, 14.5, 11) | m_poly([(28, 20), (38.5, 9), (36, 20), (38.5, 31)]) | m_poly([(13, 10), (22, 6), (24, 11)])
    frame(cv, m, '#2a8fd8', '#14508a')
    cv.fill_mask(m_ellipse(17, 25, 11, 4.5) & m & ~edge_of(m), '#4daee8')
    cv.disc(7, 17, 1.6, '#ffffff'); cv.px(7, 17, '#1a1424')

def oc_whale(cv):
    sprite(cv, ["..........B.",
                "..bbbbbb..BB",
                ".bbbbbbbbbB.",
                "bbkbbbbbbbB.",
                "bwwwwwbbbb..",
                ".wwwwwwbb..."], 18, 21, {'b': '#3a5f9a', 'B': '#2a3f6a', 'w': '#c9d8f0'}, oc='#0f2a50')
    cv.px(9, 14, '#ffffff'); cv.px(8, 13, '#ffffff'); cv.px(10, 13, '#ffffff')

def oc_octopus(cv):
    sprite(cv, ["..mmmm..",
                ".mmmmmm.",
                "mmwmmwmm",
                "mmkmmkmm",
                "mmmmmmmm",
                "m.m.m.mm",
                "m.m.m..m",
                ".m.m.m.."], 17, 20)

def oc_jelly(cv):
    sprite(cv, ["..pppp..",
                ".pjpppp.",
                "pppppppp",
                "pPpPpPpP",
                ".p.p.p..",
                "p..p..p.",
                ".p..p.p.",
                "..p...p."], 17, 20, {'j': '#f0d0ff'})

def oc_turtle(cv):
    sprite(cv, ["....nnnn....",
                "..nnTnnTnn..",
                ".nTnnnnnnTn.",
                "unnnTnnTnnnuu",
                ".nnnnnnnnnuku",
                "u.nnnnnnnn.u.",
                "u..........."], 17, 21, {'u': '#3ddc84'})

# =============== 44. Bugs — mason jar =================
def sh_jar(cv):
    frame(cv, m_rect(11, 4, 28, 8), '#8a93a6', '#4a5060')
    for x in range(12, 28, 2):
        cv.px(x, 6, '#c9d1e0')
    m = m_rrect(8, 9, 31, 36, 4)
    frame(cv, m, '#d8f0ff', '#8ab8d8')
    cv.vline(11, 13, 31, '#ffffff'); cv.vline(12, 14, 20, '#ffffff')

def bg_firefly(cv):
    cv.disc(19.5, 23, 5, '#fff6b0'); cv.disc(19.5, 23, 3.5, '#ffe24a')
    sprite(cv, ["..ww.ww..", "..wkwkw..", "...kkk...", "...kyk...", "...yyy..."], 19.5, 21, {'k': '#2b2140'}, oc='#8ab8d8')
    for (x, y) in ((13, 15), (26, 17), (14, 29), (26, 29)):
        cv.px(x, y, '#ffd23d')

def bg_bee(cv):
    sprite(cv, ["...ww.ww...",
                "...wwwww...",
                ".yykyykyy..",
                "kyykyykyyk.",
                ".yykyykyy..",
                "...k.k....."], 19.5, 22)

def bg_ladybug(cv):
    sprite(cv, ["....kk....",
                "...kkkk...",
                ".rrrkkrrr.",
                "rrkrrkrkrr",
                "rrrrrkrrrr",
                "rkrrrkrrkr",
                ".rrrrkrrr.",
                "..rrrkrr.."], 19.5, 22)

def bg_beetle(cv):
    sprite(cv, ["..k....k..",
                "...k..k...",
                "...eeee...",
                "..eEeeEe..",
                ".eEeccEee.",
                ".eEecceEe.",
                ".eEeeeeEe.",
                "..eEeeEe..",
                "...eeee..."], 19.5, 22, {'e': '#2fb07a', 'E': '#1d6b5c', 'c': '#8fffd8'})

# =============== 45. Houseplants — flower pot (plant grows out of the shape) =================
def sh_pot(cv):
    frame(cv, m_poly([(11, 27), (29, 27), (27, 38), (13, 38)]), '#c8603a', '#7a3018')
    frame(cv, m_rect(9, 24, 31, 28), '#e07a4a', '#7a3018')
    cv.hline(10, 30, 25, '#ff9a6a')

def hp_cactus(cv):
    sprite(cv, ["....ee....",
                "...eeee...",
                "e..eEee..e",
                "ee.eEee.ee",
                "eeeeEeeeee",
                ".eeeEeee..",
                "...eEee...",
                "...eEee...",
                "...eEee..."], 20, 18.5)
    cv.px(20, 13, '#ff8fb8'); cv.px(21, 13, '#ff8fb8')

def hp_monstera(cv):
    for (cx, cy, s) in ((14, 14, -1), (26, 13, 1), (20, 9, 0)):
        def f(t, cx=cx, cy=cy):
            t.ellipse(cx, cy, 5, 4, '#2e8b57'); t.ellipse(cx - 1, cy - 1, 3, 2, '#3ddc84')
            t.clear(cx + 2, cy); t.clear(cx - 3, cy + 1)
        outlined(cv, f)
    for (x, y) in ((14, 18), (26, 17), (20, 13)):
        cv.line(x, y, 20, 23, '#1f8a4c')

def hp_sunflower(cv):
    cv.line(20, 14, 20, 23, '#1f8a4c'); cv.line(21, 14, 21, 23, '#1f8a4c')
    cv.stamp(["ee..", ".ee."], 16, 19)
    def f(t):
        for k in range(10):
            a = k * math.pi / 5
            t.disc(20.5 + 4.6 * math.cos(a), 10 + 4.6 * math.sin(a), 1.6, '#ffd23d')
        t.disc(20.5, 10, 3, '#6b3f1a'); t.px(20, 9, '#a0642e')
    outlined(cv, f)

def hp_tulip(cv):
    for (x, c) in ((15, '#e8484f'), (20, '#ff8fb8'), (25, '#ffd23d')):
        top = 10 if x == 20 else 13
        cv.line(x, top + 4, 20, 23, '#1f8a4c')
        sprite(cv, ["c.c.c", "ccccc", "ccccc", ".ccc."], x, top + 1.5, {'c': c})

# =============== 46. Fruits of Türkiye — apple silhouette =================
def sh_apple(cv):
    m = m_disc(15.5, 22, 10.5) | m_disc(24.5, 22, 10.5) | m_ellipse(20, 26, 12, 10)
    m &= ~(m_disc(20, 9, 3)) & ~m_disc(20, 35.5, 1.5)
    frame(cv, m, '#ffe8dc', '#e8484f')
    cv.line(20, 11, 21, 6, '#6b3f1a')
    frame(cv, m_ellipse(25, 6, 4, 2), '#3ddc84', '#1f8a4c')

def fr_kayisi(cv):
    def f(t):
        t.disc(20, 22, 6.5, '#ff9a3d'); t.disc(18, 20, 3.5, '#ffbe6a'); t.px(17, 19, '#ffe0a0')
        t.vline(23, 16, 27, '#e07a2a')
    outlined(cv, f)
    cv.px(26, 17, '#e8484f'); cv.px(25, 18, '#e8484f')

def fr_findik(cv):
    sprite(cv, ["..ee.ee...",
                ".eEeeeEe..",
                "..nnnnn...",
                ".nnTnnnn..",
                "nnTnnnnnn.",
                "nnnnnnnnn.",
                ".nnnnnnN..",
                "..nnnnN..."], 20, 22)

def fr_incir(cv):
    def f(t):
        t.disc(20, 24, 6, '#7a3c8a'); t.ellipse(20, 18, 2.5, 3, '#7a3c8a'); t.vline(20, 13, 15, '#3ddc84')
        for y in range(20, 30):
            for x in range(20, 27):
                if (x - 20) ** 2 + (y - 24) ** 2 <= 5 ** 2:
                    t.px(x, y, '#ff8fb8' if (x + y) % 3 else '#e85a8a')
    outlined(cv, f)

def fr_kiraz(cv):
    cv.polyline([(16, 25), (20, 14), (22, 12)], '#1f8a4c'); cv.polyline([(24, 26), (21, 14)], '#1f8a4c')
    for (cx, cy) in ((16, 26), (24, 27)):
        def f(t, cx=cx, cy=cy):
            t.disc(cx, cy, 3.4, '#c8102e'); t.px(cx - 1, cy - 1, '#ff6b7a')
        outlined(cv, f)
    cv.stamp(["eee", ".ee"], 22, 11)

# =============== 47. Crystals & Gems — faceted gem =================
GEM = [(10, 7), (30, 7), (37.5, 15), (20, 36.5), (2.5, 15)]
def sh_gem(cv):
    pass

def gem(cv, lt, md, dk, name):
    m = m_poly(GEM)
    frame(cv, m, md, dk)
    cv.fill_mask(m & (YY <= 14) & ~edge_of(m), lt)
    for (a, b) in (((3, 15), (37, 15)), ((15, 7), (12, 15)), ((25, 7), (28, 15)), ((12, 15), (20, 36)), ((28, 15), (20, 36))):
        cv.line(*a, *b, dk)
    cv.fill_mask(m_poly([(12, 15), (28, 15), (20, 34)]) & ~edge_of(m), md)
    cv.line(12, 15, 20, 36, dk); cv.line(28, 15, 20, 36, dk); cv.hline(3, 37, 15, dk)
    cv.sparkle(14, 10, '#ffffff'); cv.px(24, 20, '#ffffff')
    cv.textc(name, 20, 18, '#ffffff')

def gm_amethyst(cv): gem(cv, '#e0b8ff', '#a060e0', '#5a2a90', '')
def gm_emerald(cv): gem(cv, '#a8f0c0', '#2fb070', '#156040', '')
def gm_ruby(cv): gem(cv, '#ffb0b8', '#e02a4a', '#801020', '')
def gm_sapphire(cv): gem(cv, '#b0d0ff', '#2a6fe0', '#143a80', '')

# =============== 48. Luck — four-leaf clover =================
def sh_clover(cv):
    cv.polyline([(20, 28), (22, 33), (26, 37)], '#1f8a4c'); cv.polyline([(21, 28), (23, 33), (27, 37)], '#1f8a4c')
    m = m_disc(20, 20, 6)
    for (cx, cy) in ((13, 13), (27, 13), (13, 27), (27, 27)):
        m |= m_disc(cx, cy, 7.5)
    frame(cv, m, '#3ddc84', '#1f8a4c')
    cv.fill_mask(m_disc(20, 20, 8), '#c8f8d8')

def lk_horseshoe(cv):
    def f(t):
        for k in range(-30, 211, 6):
            a = math.radians(k)
            t.disc(20 + 5 * math.cos(a), 19 - 5 * math.sin(a) * -1 + 0, 1.3, '#c9d1e0') if False else None
        for y in range(13, 28):
            for x in range(13, 28):
                d = math.hypot(x - 20, y - 18)
                if 3.2 <= d <= 6.5 and not (y > 20 and abs(x - 20) < 4):
                    t.px(x, y, '#c9d1e0')
    outlined(cv, f)
    for (x, y) in ((15, 15), (25, 15), (14, 19), (26, 19)):
        cv.px(x, y, '#4a5060')

def lk_dice(cv):
    for (x0, y0, pips) in ((13, 14, ((1, 1), (3, 3), (5, 5))), (20, 19, ((1, 1), (5, 1), (1, 5), (5, 5)))):
        def f(t, x0=x0, y0=y0, pips=pips):
            t.rect(x0, y0, x0 + 6, y0 + 6, '#ffffff')
            for (px, py) in pips:
                t.px(x0 + px, y0 + py, '#e8484f')
        outlined(cv, f)

def lk_star(cv):
    for i in range(7):
        cv.px(13 + i, 27 - i, '#ffd23d' if i % 2 else '#fff6b0')
    sprite(cv, ["..y..", ".yyy.", "yyyyy", ".yyy.", ".y.y."], 23, 16)

def lk_rainbow(cv):
    for r, c in ((7.5, '#e8484f'), (6.5, '#ff9a3d'), (5.5, '#ffd23d'), (4.5, '#3ddc84'), (3.5, '#4da3ff')):
        cv.fill_mask(m_disc(20, 23, r) & ~m_disc(20, 23, r - 1) & (YY <= 23), c)
    cv.ellipse(13, 24, 2.5, 1.5, '#ffffff'); cv.ellipse(27, 24, 2.5, 1.5, '#ffffff')

# =============== 49. Friendship — heart =================
def sh_heart(cv):
    m = m_disc(13, 14, 8.6) | m_disc(27, 14, 8.6) | m_poly([(4.6, 17), (35.4, 17), (20, 35.5)])
    frame(cv, m, '#ff6b9a', '#c23a6a')
    cv.px(9, 10, '#ffffff'); cv.px(10, 9, '#ffffff'); cv.px(8, 11, '#ffc0d4')

def fr_cheers(cv):
    glass = ["wwwwww", "woooow", ".oooo.", "..oo..", ".oooo.", "oooooo", "gggggg"]
    for x in (14, 24):
        sprite(cv, glass, x, 21, {'o': '#c0501f'})
    cv.sparkle(19, 13, '#ffffff')

def fr_bracelet(cv):
    cols = ['#ffd23d', '#4da3ff', '#3ddc84', '#ffffff', '#c86bff', '#ff9a3d']
    for k in range(12):
        a = k * math.pi / 6
        cv.disc(20 + 6 * math.cos(a), 19 + 4.5 * math.sin(a), 1.2, cols[k % 6])
    cv.textc('BFF', 20.5, 17, '#ffffff')

def fr_letter(cv):
    def f(t):
        t.rect(12, 14, 28, 25, '#ffffff')
        t.line(12, 14, 20, 20, '#c9d1e0'); t.line(28, 14, 20, 20, '#c9d1e0')
    outlined(cv, f)
    cv.stamp([".r.r.", "rrrrr", ".rrr.", "..r.."], 18, 18, {'r': '#e8304a'})

def fr_together(cv):
    sprite(cv, ["..ss....ss..",
                ".ssss..ssss.",
                ".ksks..ksks.",
                ".ssss..ssss.",
                "..ss....ss..",
                ".yyyyssbbbb.",
                "yyyyy..bbbbb",
                "yyyy....bbbb"], 20, 20)

# =============== 50. Road Trip — license plate =================
def sh_plate(cv):
    frame(cv, m_rrect(2, 10, 37, 30, 2), '#ffffff', '#2b2140')
    cv.rect(3, 11, 8, 29, '#2a4fc0')
    cv.text('T', 4, 14, '#ffffff'); cv.text('R', 4, 21, '#ffffff')
    for (x, y) in ((11, 12), (34, 12), (11, 28), (34, 28)):
        cv.px(x, y, '#8a93a6')

def plate(cv, txt, icon):
    icon(cv)
    cv.textc(txt, 22.5, 23, '#2b2140')

def rp_car(cv):
    plate(cv, '06 GO', lambda c: sprite(c, ["..eeeee...", ".eccecce..", "eeeeeeeeee", "ekeeeeekee", ".k.....k.."], 23, 16))

def rp_camper(cv):
    plate(cv, '06 VAN', lambda c: sprite(c, ["wwwwwwwww.", "wccwccwww.", "wwwwwwwwyw", "ookoooookw", "..k....k.."], 23, 16, {'o': '#ff9a3d'}))

def rp_ev(cv):
    def ic(c):
        sprite(c, ["eeeee", "ewwwe", "eeyee", "eyyye", "eeyee", "eeeee"], 20, 16)
        c.line(23, 18, 26, 18, '#2b2140'); c.vline(26, 15, 18, '#2b2140')
    plate(cv, '06 EV', ic)

def rp_map(cv):
    def ic(c):
        sprite(c, ["..rrr..", ".rrwrr.", ".rwwwr.", ".rrwrr.", "..rrr..", "...r..."], 23, 16)
    plate(cv, '06 MAP', ic)

COLLECTIONS = [
    dict(slug='41_engineering', name='Engineering Wonders', shape_name='Hard hat',
         theme='bridge, tower, pyramid, dam', shape=sh_hardhat,
         stickers=[('bridge', ew_bridge), ('tower', ew_eiffel), ('pyramid', ew_pyramid), ('dam', ew_dam)]),
    dict(slug='42_dinosaurs', name='Dinosaurs', shape_name='Bone',
         theme='T-rex, triceratops, ammonite, footprint', shape=sh_bone,
         stickers=[('trex', dn_trex), ('triceratops', dn_trike), ('ammonite', dn_ammonite), ('footprint', dn_footprint)]),
    dict(slug='43_ocean', name='Ocean Friends', shape_name='Fish',
         theme='whale, octopus, jellyfish, Caretta caretta', shape=sh_fish,
         stickers=[('whale', oc_whale), ('octopus', oc_octopus), ('jellyfish', oc_jelly), ('caretta', oc_turtle)]),
    dict(slug='44_bugs', name='Bug Jar', shape_name='Mason jar',
         theme='firefly, bee, ladybug, beetle', shape=sh_jar,
         stickers=[('firefly', bg_firefly), ('bee', bg_bee), ('ladybug', bg_ladybug), ('beetle', bg_beetle)]),
    dict(slug='45_plants', name='Dorm Plants', shape_name='Flower pot (plant forms the outline)',
         theme='cactus, monstera, sunflower, tulips', shape=sh_pot,
         stickers=[('cactus', hp_cactus), ('monstera', hp_monstera), ('sunflower', hp_sunflower), ('tulips', hp_tulip)]),
    dict(slug='46_fruits', name='Fruits of Türkiye', shape_name='Apple silhouette',
         theme='Malatya kayısı, Giresun fındığı, Aydın inciri, kiraz', shape=sh_apple,
         stickers=[('kayisi', fr_kayisi), ('findik', fr_findik), ('incir', fr_incir), ('kiraz', fr_kiraz)]),
    dict(slug='47_gems', name='Crystals & Gems', shape_name='Faceted gem',
         theme='rare tier: amethyst, emerald, ruby, sapphire', shape=sh_gem,
         stickers=[('amethyst', gm_amethyst), ('emerald', gm_emerald), ('ruby', gm_ruby), ('sapphire', gm_sapphire)]),
    dict(slug='48_luck', name='Lucky Charms', shape_name='Four-leaf clover',
         theme='horseshoe, dice, shooting star, rainbow', shape=sh_clover,
         stickers=[('horseshoe', lk_horseshoe), ('dice', lk_dice), ('shootingstar', lk_star), ('rainbow', lk_rainbow)]),
    dict(slug='49_friendship', name='Friendship', shape_name='Heart',
         theme='made for gifting: çay cheers, BFF, letter, together', shape=sh_heart,
         stickers=[('cheers', fr_cheers), ('bff', fr_bracelet), ('letter', fr_letter), ('together', fr_together)]),
    dict(slug='50_roadtrip', name='Road Trip', shape_name='License plate',
         theme='car, van, EV charge, map pin', shape=sh_plate,
         stickers=[('car', rp_car), ('van', rp_camper), ('ev', rp_ev), ('map', rp_map)]),
]

if __name__ == '__main__':
    render(COLLECTIONS, 'collections', 'sheet_batch5.png')
