"""Die-cut: Kantin Classics (8) and Türk Kahvaltısı (8)."""
import math
import numpy as np
from kit2 import *

# ======================= KANTIN =======================
def ka_cay(cv):
    def f(t):
        # saucer with red & gold rim
        t.ellipse(20, 33, 15.5, 4, '#ffffff')
        t.fill_mask(m_ellipse(20, 33, 15.5, 4) & ~m_ellipse(20, 33, 13.5, 3), '#d6202f')
        for k in range(0, 360, 30):
            a = math.radians(k)
            t.px(20 + 14.5 * math.cos(a), 33 + 3.5 * math.sin(a), '#ffd23d')
        t.ellipse(20, 32.6, 9, 1.8, '#e8eef8')
        # ince belli glass
        left = [(11, 5), (12, 10), (14, 15), (16.5, 19), (15.5, 23), (13.5, 27), (12.5, 31)]
        m = m_poly(left + [(40 - x, y) for (x, y) in reversed(left)])
        t.fill_mask(m, '#b02a12')
        t.fill_mask(m & (XX < 20), '#d23c18')
        t.fill_mask(m & (YY <= 8), '#eef6ff')
        t.fill_mask(m & (YY == 9), '#f08040')
        t.fill_mask(m & (YY == 4 + 1), '#ffd23d')
        for y in range(10, 31):
            xs = [x for x in range(40) if m[y, x]]
            if xs:
                t.px(xs[0] + 1, y, '#ff9a5a'); t.px(xs[0] + 2, y, '#ff7a40')
        # spoon + sugar cubes
        t.line(25, 2, 27, 9, '#c9d1e0'); t.line(26, 2, 28, 9, '#8a93a6')
        t.rect(29, 29, 31, 31, '#ffffff'); t.rect(32, 30, 34, 32, '#f4f4f8')
    outlined(cv, f)

def ka_simit(cv):
    def f(t):
        for y in range(S):
            for x in range(S):
                r = math.hypot(x - 20, y - 20)
                if 5.5 <= r <= 15:
                    a = math.atan2(y - 20, x - 20)
                    band = int((a + math.pi) * 18 / math.pi + r * 0.6) % 3
                    c = '#b8702e' if band == 0 else '#d18a3e'
                    if x + y < 34 and r > 8:
                        c = '#e0a050' if band else '#c8803a'
                    t.px(x, y, c)
        import random
        rnd = random.Random(3)
        for _ in range(55):
            a = rnd.random() * 2 * math.pi; r = 7 + rnd.random() * 7
            t.px(20 + r * math.cos(a), 20 + r * math.sin(a), '#fbefd5')
    outlined(cv, f)

def ka_tost(cv):
    def f(t):
        t.rect(5, 10, 34, 29, '#c8955a')
        t.rect(7, 12, 32, 27, '#e8c08a')
        for y in range(12, 28):
            for x in range(7, 33):
                if (x + y) % 5 == 0:
                    t.px(x, y, '#a0642e')
        for x in range(7, 33, 4):
            t.vline(x, 29, 30 + (x % 3), '#ffd23d')
        t.hline(6, 33, 29, '#ffd23d')
        for y in range(14, 26, 5):
            t.hline(3, 4, y, '#ffd23d')
    outlined(cv, f)

def ka_ayran(cv):
    def f(t):
        m = m_poly([(8, 8), (32, 8), (28, 34), (12, 34)])
        t.fill_mask(m, '#ffffff')
        t.fill_mask(m & (XX > 25), '#dfe8f4')
        t.rect(9, 16, 31, 23, '#2a7fd8')
        t.ellipse(20, 8, 12.5, 2.5, '#4da3ff'); t.ellipse(18, 7.5, 5, 1, '#9ad0ff')
        t.rect(29, 5, 32, 7, '#4da3ff')
        for x in range(14, 27, 3):
            t.px(x, 28, '#9ad0ff'); t.px(x + 1, 29, '#9ad0ff')
    outlined(cv, f)
    cv.textc('AYRAN', 20.5, 17, '#ffffff')

def ka_pogaca(cv):
    def f(t):
        t.ellipse(20, 23, 15, 10, '#c47a2c')
        t.ellipse(19.5, 21.5, 13.5, 8.5, '#e8a24a')
        t.ellipse(17, 18.5, 7, 3.5, '#ffc070'); t.ellipse(15, 17.5, 3, 1.4, '#ffe0a0')
        import random
        rnd = random.Random(7)
        for _ in range(26):
            x = 8 + rnd.random() * 24; y = 15 + rnd.random() * 13
            if ((x - 20) / 13) ** 2 + ((y - 21.5) / 8) ** 2 < 1:
                t.px(x, y, '#1a1424')
    outlined(cv, f)

def ka_acma(cv):
    def f(t):
        for y in range(S):
            for x in range(S):
                r = math.hypot(x - 20, y - 20)
                if 4.5 <= r <= 14.5:
                    a = math.atan2(y - 20, x - 20)
                    seg = int((a + math.pi) * 10 / (2 * math.pi) * 2) % 2
                    twist = (r - 9.5) * 0.35
                    seg = int(((a + math.pi) / (2 * math.pi) * 10 + twist) % 2)
                    c = '#d89040' if seg else '#f0b860'
                    if r > 12.5 and y > 20:
                        c = '#b8702e'
                    t.px(x, y, c)
        for (x, y) in ((12, 12), (15, 10), (26, 11), (29, 15), (11, 17)):
            t.px(x, y, '#fff0c8')
    outlined(cv, f)

def ka_kahve(cv):
    def f(t):
        # saucer
        t.ellipse(19, 31, 17, 4.5, '#ffffff')
        t.fill_mask(m_ellipse(19, 31, 17, 4.5) & ~m_ellipse(19, 31, 15, 3.4), '#2a5fc0')
        t.ellipse(19, 30.5, 10, 2, '#e8eef8')
        # handle
        for y in range(S):
            for x in range(S):
                d = math.hypot((x - 28) / 1.0, (y - 18) / 1.15)
                if 2.2 <= d <= 4.4 and x > 26:
                    t.px(x, y, '#ffffff')
        # fincan body (tapered, rounded bottom)
        body = m_poly([(8, 10), (30, 10), (28, 22), (24, 28), (14, 28), (10, 22)])
        t.fill_mask(body, '#ffffff')
        t.fill_mask(body & (XX > 25), '#e2e8f4')
        t.fill_mask(body & (YY >= 14) & (YY <= 17), '#2a5fc0')
        for x in range(10, 29, 3):
            t.px(x, 15, '#ffd23d'); t.px(x + 1, 16, '#ffffff')
        t.fill_mask(body & (YY == 12), '#ffd23d')
        # coffee + köpük
        t.ellipse(19, 10, 11, 2.6, '#4a2a14')
        t.ellipse(19, 10, 9, 1.8, '#c8955a')
        t.px(15, 10, '#e8c08a'); t.px(22, 9, '#e8c08a'); t.px(19, 10, '#e8c08a')
        # lokum
        for (x0, y0) in ((30, 27), (33, 25)):
            t.rect(x0, y0, x0 + 3, y0 + 3, '#ff6b9a'); t.hline(x0, x0 + 3, y0, '#ffffff'); t.px(x0, y0 + 1, '#ffd0e0')
    outlined(cv, f)

def ka_gofret(cv):
    def f(t):
        t.rect(4, 13, 35, 27, '#e8c08a')
        for x in range(4, 23):
            for y in range(13, 28):
                if x % 3 == 0 or y % 3 == 0:
                    t.px(x, y, '#c8955a')
        t.rect(23, 12, 35, 28, '#6b3f1a'); t.rect(24, 13, 34, 15, '#8a5a30')
        for x in range(23, 36):
            if x % 4 == 1:
                t.vline(x, 28, 29, '#6b3f1a')
        t.vline(22, 13, 27, '#6b3f1a')
    outlined(cv, f)

# ======================= KAHVALTI =======================
def sahan(t):
    t.rect(1, 19, 6, 23, '#a0582a'); t.rect(33, 19, 38, 23, '#a0582a')
    t.ellipse(20, 21, 15, 12, '#c8703a')
    t.ellipse(20, 20, 13.5, 10.5, '#e89060')
    t.ellipse(20, 21, 12.5, 9.5, '#8a4a20')

def kh_menemen(cv):
    def f(t):
        sahan(t)
        t.ellipse(20, 21, 11.5, 8.5, '#d8402f'); t.ellipse(19, 20, 9, 6.5, '#e8584a')
        for (x, y, r) in ((14, 18, 2.6), (22, 16, 2.2), (24, 24, 2.8), (13, 24, 2), (19, 21, 1.8), (28, 19, 1.8)):
            t.disc(x, y, r, '#ffd23d'); t.px(x - 1, y - 1, '#fff0a0')
        for (x, y) in ((17, 15), (26, 21), (16, 27), (10, 20), (21, 27), (29, 23)):
            t.hline(x, x + 1, y, '#3ddc84'); t.px(x, y + 1, '#1f8a4c')
    outlined(cv, f)

def kh_sucuklu(cv):
    def f(t):
        sahan(t)
        t.ellipse(20, 21, 11.5, 8.5, '#ffffff')
        for (cx, cy) in ((15, 19), (24, 23)):
            t.disc(cx, cy, 3, '#ffb02e'); t.px(cx - 1, cy - 1, '#ffe0a0')
        for (x, y) in ((24, 16), (13, 25), (28, 20), (19, 26), (11, 19), (20, 15)):
            t.disc(x, y, 1.9, '#a3222b'); t.px(x, y, '#e87a80')
    outlined(cv, f)

def kh_peynir(cv):
    def f(t):
        t.ellipse(20, 24, 16, 10, '#ffffff'); t.ellipse(20, 24, 13, 7.5, '#e8eef8')
        for (x0, y0) in ((9, 15), (21, 17)):
            t.rect(x0, y0, x0 + 10, y0 + 9, '#fbf8ee'); t.hline(x0, x0 + 10, y0, '#ffffff')
            t.vline(x0 + 10, y0, y0 + 9, '#e0dccc'); t.hline(x0, x0 + 10, y0 + 9, '#e0dccc')
            t.px(x0 + 3, y0 + 4, '#ece8d8'); t.px(x0 + 7, y0 + 6, '#ece8d8')
        t.stamp([".ee.", "eeee", ".eE.", "..E."], 29, 11)
        for (x, y) in ((12, 26), (24, 28), (17, 13)):
            t.px(x, y, '#c8d040')
    outlined(cv, f)

def kh_zeytin(cv):
    def f(t):
        t.ellipse(20, 23, 16, 11, '#fbefd5'); t.ellipse(20, 22, 13.5, 8.5, '#e8d8b8')
        import random
        rnd = random.Random(5)
        pts = [(13, 19), (20, 17), (27, 20), (16, 25), (23, 25), (11, 24), (29, 26)]
        for i, (x, y) in enumerate(pts):
            c, d, h = (('#2b2140', '#14101e', '#7a6aa0') if i % 2 else ('#7a9a2a', '#4a6a10', '#d8f080'))
            t.ellipse(x, y, 3.4, 2.6, d); t.ellipse(x - 0.5, y - 0.5, 2.8, 2, c)
            t.px(x - 1, y - 1, h); t.px(x, y - 1, h)
    outlined(cv, f)

def kh_balkaymak(cv):
    def f(t):
        t.ellipse(20, 25, 16, 10, '#ffffff'); t.ellipse(20, 25, 13, 7.5, '#e8eef8')
        t.rect(8, 18, 22, 26, '#fff8e8'); t.hline(8, 22, 18, '#ffffff'); t.hline(8, 22, 26, '#e8dcc0')
        for x in range(8, 23):
            t.px(x, 18 + int(1.5 + 1.5 * math.sin(x * 0.9)), '#ffb02e')
        t.vline(15, 19, 24, '#ffb02e'); t.vline(19, 20, 23, '#ffb02e')
        for (cx, cy) in ((27, 20), (31, 22), (27, 25), (31, 27)):
            for j in range(-2, 3):
                half = 2 - abs(j) // 2
                t.hline(cx - half, cx + half, cy + j, '#ffb02e')
            t.px(cx, cy, '#ffe08a')
    outlined(cv, f)

def kh_domates(cv):
    for (cx, cy) in ((14, 15), (26, 14), (20, 25)):
        def f(t, cx=cx, cy=cy):
            t.disc(cx, cy, 7, '#e8484f'); t.disc(cx, cy, 5.5, '#ff6a6a')
            for k in range(6):
                a = k * math.pi / 3
                t.ellipse(cx + 3 * math.cos(a), cy + 3 * math.sin(a), 1.2, 1.2, '#ffe08a')
            t.px(cx, cy, '#ffb0b0')
        outlined(cv, f)
    for (cx, cy) in ((9, 28), (31, 27)):
        def g(t, cx=cx, cy=cy):
            t.disc(cx, cy, 5, '#2e8b57'); t.disc(cx, cy, 4, '#c8f0b0')
            for k in range(5):
                a = k * 2 * math.pi / 5
                t.px(cx + 2 * math.cos(a), cy + 2 * math.sin(a), '#f8fff0')
        outlined(cv, g)

def kh_recel(cv):
    def f(t):
        t.rect(10, 4, 29, 9, '#e8484f')
        for x in range(10, 30):
            for y in range(4, 10):
                if (x // 2 + y // 2) % 2 == 0:
                    t.px(x, y, '#ffffff')
        t.hline(11, 28, 10, '#c9d1e0')
        m = m_rrect(9, 11, 30, 35, 4)
        t.fill_mask(m, '#7a1028')
        t.fill_mask(m & (YY <= 13), '#e8f0ff')
        t.rect(12, 20, 27, 28, '#fbefd5'); t.hline(12, 27, 20, '#e8d8b8')
        t.vline(11, 15, 32, '#c03050')
    outlined(cv, f)
    cv.disc(17, 24, 1.8, '#c8102e'); cv.disc(22, 25, 1.8, '#c8102e'); cv.line(17, 22, 20, 21, '#2e8b57'); cv.line(22, 23, 20, 21, '#2e8b57')

def kh_borek(cv):
    rolls = [((5, 26), (34, 12)), ((6, 16), (34, 28)), ((9, 31), (31, 7))]
    for (a, b) in rolls:
        def f(t, a=a, b=b):
            for off in range(-2, 3):
                nx, ny = -(b[1] - a[1]), (b[0] - a[0])
                L = math.hypot(nx, ny); nx, ny = nx / L, ny / L
                c = '#f0b860' if off < 0 else ('#d89040' if off > 0 else '#ffd080')
                t.line(a[0] + off * nx, a[1] + off * ny, b[0] + off * nx, b[1] + off * ny, c)
            t.px(a[0], a[1], '#fbefd5'); t.px(b[0], b[1], '#fbefd5')
        outlined(cv, f)
    cv.stamp([".ee.", "eEee", ".ee."], 16, 18)

COLLECTIONS = [
    dict(slug='04_kantin', name='Kantin Classics', shape_name='die-cut',
         stickers=[('cay', ka_cay), ('simit', ka_simit), ('tost', ka_tost), ('ayran', ka_ayran),
                   ('pogaca', ka_pogaca), ('acma', ka_acma), ('turk_kahvesi', ka_kahve), ('gofret', ka_gofret)]),
    dict(slug='05_kahvalti', name='Türk Kahvaltısı', shape_name='die-cut',
         stickers=[('menemen', kh_menemen), ('sucuklu_yumurta', kh_sucuklu), ('beyaz_peynir', kh_peynir), ('zeytin', kh_zeytin),
                   ('bal_kaymak', kh_balkaymak), ('domates_salatalik', kh_domates), ('visne_receli', kh_recel), ('sigara_boregi', kh_borek)]),
]

if __name__ == '__main__':
    for c in COLLECTIONS:
        render_collection(c)
